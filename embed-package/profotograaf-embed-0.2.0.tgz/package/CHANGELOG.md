# Changelog

Versions follow semver. The markup contract (`contract/markup.json`) only grows within a major version; a removal or rename is a new major (see `contract/README.md`).

## 0.2.0

- A server draws the look of a gallery: column counts (`data-columns`, `-tablet`, `-mobile`), gap (`data-gap`, `data-gap-row`, `data-gap-column`), radius (`data-radius`, a number or `full`), shadow (`data-shadow`) and hover (`data-hover`, `data-hover-strength`). A host div that sets any of them was sent back to the client before, which showed a blank box and shifted the layout (#2789). The markup contract is unchanged: the classes and custom properties already existed.
- With the `grow` hover the server marks each tile, or the figure around tile and caption, with the `u` class, as `embed.js` does.
- `fixtures/`: ten `look-*` cases with their `*.expected.html` and `*.server.html`, for the WordPress plugin's parity test: `look-columns`, `look-columns-cap` (more columns than photos), `look-gap-radius`, `look-gap-flush`, `look-radius-full`, `look-radius-full-masonry` (the full radius is ignored), `look-shadow-hover`, `look-shadow-strong-grow`, `look-hover-none` and `look-hover-grow-captions`.
- Still drawn by the client only: `data-gutter`, `data-frame`, `data-duotone`, `data-ratio`, `data-image-text`, `data-link-to`, `data-link-new-tab`, `data-sort`, `data-exclude`, `data-per-page` and `data-load-more`.

## 0.1.1

- The API origin comes from a `data-platform` attribute on the script tag when it holds an absolute https origin, and from the script URL otherwise. A copy served from the WordPress plugin folder now reaches the platform (#2653). `contract/markup.json` lists the attribute in a new `script` section.

## 0.1.0

First packaged version (#2530).

- `dist/embed.js`: the gallery embed's interactive layer as one readable script with a source map. It adopts a server-drawn shadow root and draws the grid, masonry and slideshow layouts, the lightbox, favourites and proofing hooks itself when the host sends none.
- `src/`: the TypeScript the script is built from.
- `contract/markup.json` and `contract/majors/1.json`: the markup contract, major 1.
- `fixtures/`: gallery API responses with the expected markup (`*.expected.html`) and the server-drawn markup (`*.server.html`), for the WordPress plugin's parity test.

// Styles live inside the shadow root, so host CSS cannot change them and they
// cannot leak out. The host element itself only needs to be a block.

/**
 * Container widths (px) the @container rules below switch at, published on the host as
 * data-pf-breakpoints. Order and meaning are a contract: tiny caption, compact
 * slideshow, phone, tablet. A unit test keeps this list equal to the rules in EMBED_CSS.
 */
export const BREAKPOINTS = [239, 599, 600, 900] as const;

export const EMBED_CSS = `
:host{all:initial;display:block;font:14px/1.4 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#1a1a1a}
*{box-sizing:border-box}
.gallery,.lb,.badge{letter-spacing:normal;word-spacing:normal;text-transform:none;text-indent:0;font-style:normal}
.gallery{width:100%}
button{font:inherit;color:inherit;margin:0}
.tile{display:block;width:100%;padding:0;border:0;background:#e9e7e3;cursor:zoom-in;overflow:hidden;border-radius:var(--radius,4px)}
.tile.static{cursor:default}
a.tile{cursor:pointer;color:inherit;text-decoration:none}
.photos .tile{position:relative}
.tile img{display:block;width:100%;height:auto}
.tile:focus-visible,.nav:focus-visible,.dot:focus-visible,.lb button:focus-visible,.badge:focus-visible{outline:3px solid #2456d6;outline-offset:2px}
.grid .photos{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));row-gap:var(--gap-row,var(--gap,8px));column-gap:var(--gap-col,var(--gap,8px))}
.grid .tile{aspect-ratio:1/1}
.grid .tile img{height:100%;object-fit:cover}
.pf{container-type:inline-size;padding-inline:var(--gutter,0)}
.masonry .photos{display:flex;align-items:flex-start;column-gap:var(--gap-col,var(--gap,8px))}
.mcol{flex:1 1 0;min-width:0;display:flex;flex-direction:column;row-gap:var(--gap-row,var(--gap,8px))}
/* Before the columns exist (server markup, no script): tiles wrap in reading order. */
.masonry .photos{flex-wrap:wrap;row-gap:var(--gap-row,var(--gap,8px))}
.masonry .photos>:not(.mcol){flex:1 1 220px;min-width:0}
.item{margin:0}
.below{padding:6px 2px 0;font-size:13px;color:#4a4640}
.cap{position:absolute;left:0;right:0;bottom:0;padding:18px 8px 6px;text-align:left;font-size:13px;color:#fff;background:linear-gradient(transparent,rgba(0,0,0,.65))}
.ov{position:relative;container-type:inline-size}
.ov .cap{pointer-events:none;border-radius:0 0 var(--radius,4px) var(--radius,4px)}
@container (max-width:239px){
.ov .cap{position:static;pointer-events:auto;padding:6px 2px 0;color:#4a4640;background:none;border-radius:0;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;line-clamp:2;overflow:hidden}
}
.gallery[style*="--cols:"]{--n:var(--cols)}
.gallery[style*="--cols:"].grid .photos{grid-template-columns:repeat(var(--n),1fr)}
@container (max-width:900px){
.gallery[style*="--cols:"]{--n:min(var(--cols),3)}
.gallery[style*="--cols-tablet:"]{--n:var(--cols-tablet)}
.gallery[style*="--cols-tablet:"].grid .photos{grid-template-columns:repeat(var(--n),1fr)}
}
@container (max-width:600px){
.gallery[style*="--cols:"].grid{--n:min(var(--cols),2)}
.gallery[style*="--cols-tablet:"].grid{--n:min(var(--cols-tablet),2)}
.gallery[style*="--cols-mobile:"],.gallery[style*="--cols-mobile:"].grid{--n:var(--cols-mobile)}
.gallery[style*="--cols-mobile:"].grid .photos{grid-template-columns:repeat(var(--n),1fr)}
}
.gallery[style*="--orig"].grid{--rowh:160px}
.gallery[style*="--orig"][style*="--cols:"].grid,.gallery[style*="--orig"][style*="--cols-tablet:"].grid,.gallery[style*="--orig"][style*="--cols-mobile:"].grid{--rowh:calc((100% - (var(--n,5) - 1)*var(--gap-col,var(--gap,8px)))/var(--n,5)/1.5*.999)}
.gallery[style*="--orig"].grid .photos{display:flex;flex-wrap:wrap;align-items:flex-start;row-gap:var(--gap-row,var(--gap,8px));column-gap:var(--gap-col,var(--gap,8px))}
.gallery[style*="--orig"].grid .photos>*{flex:var(--ar,1.5) 1 calc(var(--ar,1.5)*var(--rowh));min-width:0}
.gallery[style*="--orig"].grid .photos::after{content:"";flex:calc(1000*min(1,max(0,var(--orig) - var(--n,0)))) 1 0;margin-top:calc(-1*var(--gap-row,var(--gap,8px)))}
.gallery[style*="--orig"].grid .tile{aspect-ratio:var(--ar,1.5)}
.gallery[style*="--ratio"] .photos .tile,.gallery[style*="--ratio"] .stage .tile{aspect-ratio:var(--ratio)}
.gallery[style*="--ratio"] .photos .tile img,.gallery[style*="--ratio"] .stage .tile img{height:100%;object-fit:cover}
.duo .tile img{filter:url(#pf-duo)}
.more{display:block;margin:12px auto 0;padding:10px 18px;min-height:44px;border:1px solid #bdb9b1;border-radius:4px;background:#fff;cursor:pointer}
.more[hidden]{display:none}
.slideshow{container-type:inline-size}
.slides{display:grid;grid-template-columns:44px 1fr 44px;grid-template-areas:"frame frame frame" "prev pager next"}
.frame{position:relative;grid-area:frame}
.stage{position:relative;overflow:hidden;background:#111;border-radius:var(--radius,4px)}
.stage .tile{position:relative;aspect-ratio:var(--pr,3/2);background:transparent;cursor:zoom-in}
.gallery:not([style*="--ratio"]) .stage .tile{max-height:80vh}
.stage .tile img{position:absolute;inset:0;width:100%;height:100%;object-fit:contain}
.gallery[style*="--ratio"] .stage .tile img{object-fit:cover}
.stage .bg{position:absolute;inset:-24px;width:calc(100% + 48px);height:calc(100% + 48px);object-fit:cover;filter:blur(24px) brightness(.45);pointer-events:none}
.nav{position:absolute;top:calc(50% - 22px);width:44px;height:44px;border:0;border-radius:50%;background:rgba(0,0,0,.55);color:#fff;font-size:28px;line-height:1;cursor:pointer}
.prev{left:8px}.next{right:8px}
.dots,.count{grid-area:pager}
.dots{display:flex;flex-wrap:wrap;justify-content:center;align-items:center;gap:0;margin-top:4px}
.dot{width:24px;height:24px;padding:0;border:0;background:none;cursor:pointer;position:relative}
.dot::after{content:"";position:absolute;inset:8px;border-radius:50%;background:#9a968f}
.dot[aria-current=true]::after{background:#1a1a1a}
.count{display:flex;justify-content:center;align-items:center;margin-top:4px;min-height:44px;font-variant-numeric:tabular-nums;color:#4a4640}
@container (max-width:599px){
.frame{display:contents}
.stage{grid-area:frame}
.nav{position:static;margin-top:4px;background:#1a1a1a}
.prev{grid-area:prev;justify-self:start}
.next{grid-area:next;justify-self:end}
}
.badge{display:inline-block;margin-top:8px;padding:4px 0;color:#5a5650;font-size:12px;text-decoration:none}
.badge:hover{text-decoration:underline}
.badge.prominent{display:block;text-align:center;padding:10px 12px;background:#1a1a1a;color:#fff;font-size:14px;border-radius:4px}
.lb{position:fixed;inset:0;z-index:2147483000;display:flex;flex-direction:column;align-items:center;justify-content:center;background:rgba(10,10,10,.97);color:#fff;font:14px/1.4 system-ui,sans-serif;touch-action:pan-y}
.lb figure{margin:0;max-width:100%;max-height:100%;display:flex;flex-direction:column;align-items:center;padding:56px 56px 16px}
.lb img{height:auto;max-width:100%;max-height:calc(100vh - 170px);max-height:calc(100dvh - 170px);object-fit:contain}
.lb figcaption{margin-top:12px;text-align:center;max-width:70ch}
.lb .title{font-weight:600}
.lb button{position:absolute;width:44px;height:44px;border:0;border-radius:50%;background:rgba(255,255,255,.14);color:#fff;font-size:26px;line-height:1;cursor:pointer}
.lb .x{top:8px;right:8px}.lb .p{left:8px;top:calc(50% - 22px)}.lb .n{right:8px;top:calc(50% - 22px)}
.lb button[hidden]{display:none}
.lb .count{position:absolute;top:18px;left:16px;font-size:13px;color:#e6e6e6}
@media (max-width:600px){.lb figure{padding:56px 8px 64px}.lb .p,.lb .n{top:auto;bottom:12px}.lb .p{left:12px}.lb .n{right:12px}}
.gallery[style*="--frame-w"] .photos .tile{border:var(--frame-w) solid var(--frame-c)}
.sh-soft .photos .tile{box-shadow:0 2px 8px rgba(0,0,0,.18)}
.sh-strong .photos .tile{box-shadow:0 6px 18px rgba(0,0,0,.38)}
.rfull .ov .cap{left:12%;right:12%;bottom:10%;padding:5px 6px;text-align:center;border-radius:999px;background:rgba(0,0,0,.6)}
@container (max-width:239px){
.rfull .ov .cap{position:static;padding:6px 2px 0;border-radius:0;background:none}
}
@media (prefers-reduced-motion:no-preference){
.tile img{transition:transform .25s}
.tile:hover img,.tile:focus-visible img{transform:scale(1.02)}
.hs-strong .tile:hover img,.hs-strong .tile:focus-visible img{transform:scale(1.06)}
.hv-none .tile:hover img,.hv-none .tile:focus-visible img,.hv-grow .tile:hover img,.hv-grow .tile:focus-visible img{transform:none}
.hv-grow .photos .u{position:relative;transition:transform .2s,box-shadow .2s}
.hv-grow .photos .u:hover{transform:scale(1.03);z-index:2}
.hv-grow.hs-strong .photos .u:hover{transform:scale(1.06)}
.hv-grow .photos .tile.u:hover,.hv-grow .photos .tile.u:focus-visible{box-shadow:0 10px 24px rgba(0,0,0,.3)}
.hv-grow .photos .tile.u:focus-visible{transform:scale(1.03);z-index:2}
.hv-grow.hs-strong .photos .tile.u:focus-visible{transform:scale(1.06)}
.hv-grow .photos .item.u:hover .tile{box-shadow:0 10px 24px rgba(0,0,0,.3)}
.hv-grow .photos .item.u:has(.tile:focus-visible){transform:scale(1.03);z-index:2}
.hv-grow.hs-strong .photos .item.u:has(.tile:focus-visible){transform:scale(1.06)}
.hv-grow .photos .item.u:has(.tile:focus-visible) .tile{box-shadow:0 10px 24px rgba(0,0,0,.3)}
}
`;

// Server-side markup for the gallery embed (#2530): the same tree render()
// draws, as a declarative shadow root (<template shadowrootmode="open">). A
// server that cannot run the embed writes this next to the host div; embed.js
// then adopts it (adopt.ts) instead of fetching and redrawing. The WordPress
// plugin's PHP renderer is a port of this file and is held to the same fixtures.
//
// Only what a server can draw without measuring anything: grid and masonry (one
// ordered list, no columns), captions off, below or overlay, the lightbox tile
// and the badge, plus the look options that only set a class or a custom
// property: columns, gap, radius, shadow and hover. Everything else returns
// null and the client draws it.

import { EMBED_CSS } from "./css";
import { badgeText, pickLocale } from "./i18n";
import { lookClasses } from "./look";
import { cssVars, parseOptions, selectPhotos, type EmbedOptions } from "./options";
import { resolveLayout } from "./layouts";
import type { EmbedGallery, EmbedPhoto } from "./types";

const SERVED_LAYOUTS = ["grid", "masonry"];
/** Options whose output depends on the client; any other value than the default sends the embed back to the client. */
const SERVER_OPTIONS = [
  "captions",
  "badge",
  // Look (#2789): they only change a class or a custom property, which cssVars and lookClasses write below.
  "columns",
  "columnsTablet",
  "columnsMobile",
  "gap",
  "gapRow",
  "gapColumn",
  "radius",
  "radiusFull",
  "hover",
  "hoverStrength",
  "shadow",
] as const;

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

/** The options a server draws: the caption mode, the badge and the look (columns, gap, radius, shadow, hover). All others stay at their defaults. */
function servable(o: EmbedOptions, defaults: EmbedOptions): boolean {
  const strip = (x: EmbedOptions) => {
    const copy: Record<string, unknown> = { ...x };
    for (const k of SERVER_OPTIONS) delete copy[k];
    return JSON.stringify(copy);
  };
  return strip(o) === strip(defaults);
}

function photoAlt(p: EmbedPhoto, g: EmbedGallery, i: number): string {
  return p.alt || p.title || p.caption || `${g.title} ${i + 1}`;
}

function srcsetOf(p: EmbedPhoto, squareOnly: boolean): string {
  const ratio = p.width && p.height ? p.width / p.height : 0;
  return p.images
    .filter((im) => squareOnly || im.variant !== "thumb" || (ratio && Math.abs(im.width / im.height - ratio) < 0.03))
    .map((im) => `${im.url} ${im.width}w`)
    .join(", ");
}

function bestUrl(p: EmbedPhoto): string {
  const web = p.images.find((im) => im.variant === "web") ?? p.images[p.images.length - 1];
  return web ? web.url : "";
}

function img(p: EmbedPhoto, g: EmbedGallery, i: number, layout: string): string {
  const grid = layout === "grid";
  const set = srcsetOf(p, grid);
  const a = [`alt="${esc(photoAlt(p, g, i))}"`, `src="${esc(bestUrl(p))}"`];
  if (set) a.push(`srcset="${esc(set)}"`, `sizes="${grid ? "(max-width: 600px) 50vw, 33vw" : "(max-width: 600px) 100vw, 50vw"}"`);
  if (p.width && p.height) a.push(`width="${p.width}"`, `height="${p.height}"`);
  a.push('loading="lazy"', 'decoding="async"', 'draggable="false"');
  return `<img ${a.join(" ")}>`;
}

function tile(p: EmbedPhoto, g: EmbedGallery, i: number, layout: string, o: EmbedOptions): string {
  // The grow hover scales the outermost element as a whole, so the client marks it with "u".
  const u = o.hover === "grow" ? " u" : "";
  const text = o.captions === "off" ? "" : [p.title, p.caption].filter(Boolean).join(" - ");
  const button = `<button class="tile${text ? "" : u}" type="button" aria-label="${esc(photoAlt(p, g, i))}">${img(p, g, i, layout)}</button>`;
  if (!text) return button;
  if (o.captions === "below") return `<figure class="item${u}">${button}<figcaption class="below">${esc(text)}</figcaption></figure>`;
  return `<figure class="item ov${u}">${button}<figcaption class="cap">${esc(text)}</figcaption></figure>`;
}

/**
 * The declarative shadow root for a gallery and the attributes of its host div,
 * or null when the client has to draw it.
 */
export function renderDeclarative(gal: EmbedGallery, attrs: Record<string, string>, lang = ""): string | null {
  const o = parseOptions((n) => attrs[n] ?? null);
  const layout = resolveLayout(attrs["data-layout"] ?? null, gal.layout);
  if (!SERVED_LAYOUTS.includes(layout) || !gal.photos.length) return null;
  if (!servable(o, parseOptions(() => null)) || !o.lightbox) return null;
  const photos = selectPhotos(gal.photos, o);
  if (!photos.length) return null;
  const g = { ...gal, photos };
  pickLocale(lang);
  const classes = ["gallery", layout, ...lookClasses(o, layout)].join(" ");
  const vars = cssVars(o, photos.length, layout);
  const style = vars ? ` style="${esc(vars)}"` : "";
  const tiles = photos.map((p, i) => tile(p, g, i, layout, o)).join("");
  const badge =
    o.badge && g.badge?.show
      ? `<a class="${g.badge.prominent ? "badge prominent" : "badge"}" href="${esc(g.badge.url)}" target="_blank" rel="noopener">${esc(badgeText())}</a>`
      : "";
  return `<template shadowrootmode="open"><style>${EMBED_CSS}</style><div class="pf"><div class="${classes}"${style}><div class="photos">${tiles}</div></div></div>${badge}</template>`;
}

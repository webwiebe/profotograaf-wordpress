// A third-party page cannot load our translation catalogue, so the embed keeps
// its four strings inline and picks the language from the div's lang attribute
// or the host page's <html lang>. Anything else falls back to English.
// The accessor is called label() because check-i18n resolves every t("key") call against
// the web catalogue, which this bundle does not use.

const STRINGS = {
  en: { close: "Close", prev: "Previous photo", next: "Next photo", badge: "Made with Profotograaf", more: "Show more" },
  nl: { close: "Sluiten", prev: "Vorige foto", next: "Volgende foto", badge: "Gemaakt met Profotograaf", more: "Toon meer" },
} as const;

type Lang = keyof typeof STRINGS;
type Key = keyof (typeof STRINGS)["en"];

let lang: Lang = "en";

export function pickLocale(tag: string | null | undefined): Lang {
  const base = (tag || "").toLowerCase().split("-")[0];
  lang = base === "nl" ? "nl" : "en";
  return lang;
}

export function label(key: Key): string {
  return STRINGS[lang][key];
}

export function badgeText(): string {
  return label("badge");
}

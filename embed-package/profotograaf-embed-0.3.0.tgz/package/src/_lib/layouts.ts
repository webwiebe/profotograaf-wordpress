// Maps every platform gallery layout (internal/gallerylayout.All) onto the
// layout embed.js can draw (#2359). Pure, so it is unit tested without a DOM.
// internal/gallerylayout/embed_test.go reads EMBED_LAYOUT_OF and fails when it
// disagrees with the Go table, so a new platform layout cannot ship unmapped.

export const DRAWN_LAYOUTS = ["grid", "masonry", "slideshow"] as const;
export type DrawnLayout = (typeof DRAWN_LAYOUTS)[number];

export const EMBED_LAYOUT_OF: Record<string, DrawnLayout> = {
  masonry: "masonry",
  justified: "masonry",
  mosaic: "masonry",
  lighttable: "masonry",
  editorial: "masonry",
  parallax: "slideshow",
  direct: "slideshow",
  cinema: "slideshow",
  filmstrip: "slideshow",
  slideout: "slideshow",
  flickr: "grid",
  instagram: "grid",
  duo: "grid",
};

function drawnOf(name: string): DrawnLayout | undefined {
  return DRAWN_LAYOUTS.find((l) => l === name) ?? EMBED_LAYOUT_OF[name];
}

/**
 * The layout to draw. An explicit drawn value in `attr` (what the WordPress
 * plugin sends) passes through unchanged; a platform layout name there is
 * mapped; otherwise the gallery's own layout is mapped; otherwise grid.
 */
export function resolveLayout(attr: string | null, galleryLayout: string): DrawnLayout {
  const a = (attr || "").trim().toLowerCase();
  const g = (galleryLayout || "").trim().toLowerCase();
  return drawnOf(a) ?? drawnOf(g) ?? "grid";
}

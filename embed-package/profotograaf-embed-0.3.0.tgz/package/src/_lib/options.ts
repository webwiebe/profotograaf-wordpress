// Per-embed options read from data-* attributes (#1870). Every attribute is
// optional; an absent or unrecognised value yields undefined (or the neutral
// default), so the output matches what embed.js rendered before these existed.

import { hex, MAX_GAP, parseBoundedInt } from "./parse";
import { lookVars, parseLook, type Look } from "./look";
import type { EmbedPhoto } from "./types";

const CAPTIONS = ["off", "below", "overlay"] as const;
const SORTS = ["default", "reverse", "title", "random"] as const;
/** What the WordPress plugin sends, mapped to the sorts above. The API lists photos oldest first. */
const SORT_ALIASES: Record<string, (typeof SORTS)[number]> = { newest: "reverse", oldest: "default", name: "title" };
const LINK_TOS = ["none", "page", "site", "file"] as const;

export interface EmbedOptions extends Look {
  columns?: number;
  columnsTablet?: number;
  columnsMobile?: number;
  gap?: number;
  /** Inline padding when the embed is as wide as the viewport; defaults to the gap. */
  gutter?: number;
  ratio?: { w: number; h: number };
  /** data-ratio="original": every tile keeps its photo's own proportions. */
  ratioOriginal: boolean;
  captions: (typeof CAPTIONS)[number];
  duotone?: [string, string];
  sort: (typeof SORTS)[number];
  perPage?: number;
  /** With per-page set: show the "Show more" button. Off shows the first page only. */
  loadMore: boolean;
  lightbox: boolean;
  /** What a tile links to when the lightbox is off. */
  linkTo?: (typeof LINK_TOS)[number];
  linkNewTab: boolean;
  exclude: Set<string>;
  /** data-badge="off" hides the "Made with" credit the platform would show. Any other value leaves the platform to decide. */
  badge: boolean;
  /** data-image-text (#2459): caption and alt overrides by photo id. */
  imageText?: ImageText;
}

export type ImageText = Map<string, { caption?: string; alt?: string }>;

const IMAGE_TEXT_ENTRIES = 200;
const IMAGE_TEXT_CHARS = 500;

type Attr = (name: string) => string | null;

/** "4:3", "4/3", "4x3" or a single number such as "1.5". */
export function parseRatio(v: string | null): { w: number; h: number } | undefined {
  const m = /^\s*(\d+(?:\.\d+)?)\s*(?:[:/x]\s*(\d+(?:\.\d+)?))?\s*$/.exec(v ?? "");
  if (!m) return undefined;
  const w = Number(m[1]);
  const h = m[2] === undefined ? 1 : Number(m[2]);
  if (!(w > 0 && h > 0) || w > 100 || h > 100 || w / h > 10 || h / w > 10) return undefined;
  return { w, h };
}

/** Two hex colours (shadow, highlight), comma or space separated, "#" optional. Returned as #rrggbb. */
export function parseDuotone(v: string | null): [string, string] | undefined {
  const parts = (v ?? "").trim().split(/[\s,]+/);
  if (parts.length !== 2) return undefined;
  const a = hex(parts[0]);
  const b = hex(parts[1]);
  return a && b ? [a, b] : undefined;
}

function textOf(v: unknown): string | undefined {
  return typeof v === "string" && v ? v.slice(0, IMAGE_TEXT_CHARS) : undefined;
}

/** A JSON array of {id, caption, alt}. Invalid JSON, unknown shapes and entries without text are ignored. */
export function parseImageText(v: string | null): ImageText | undefined {
  let list: unknown;
  try {
    list = JSON.parse(v ?? "");
  } catch {
    return undefined;
  }
  if (!Array.isArray(list)) return undefined;
  const out: ImageText = new Map();
  for (const e of list.slice(0, IMAGE_TEXT_ENTRIES)) {
    const r = (e ?? {}) as Record<string, unknown>;
    const caption = textOf(r.caption);
    const alt = textOf(r.alt);
    if (typeof r.id === "string" && r.id && (caption || alt)) out.set(r.id, { caption, alt });
  }
  return out.size ? out : undefined;
}

function oneOf<T extends string>(list: readonly T[], v: string | null, fallback: T): T {
  const s = (v ?? "").trim().toLowerCase();
  return list.find((x) => x === s) ?? fallback;
}

/** on/true/1/yes and off/false/0/no; anything else is the fallback. */
function parseFlag(v: string | null, fallback: boolean): boolean {
  const s = (v ?? "").trim().toLowerCase();
  if (s === "on" || s === "true" || s === "1" || s === "yes") return true;
  if (s === "off" || s === "false" || s === "0" || s === "no") return false;
  return fallback;
}

function sortOf(v: string | null): (typeof SORTS)[number] {
  const s = (v ?? "").trim().toLowerCase();
  return SORT_ALIASES[s] ?? oneOf(SORTS, s, "default");
}

export function parseOptions(attr: Attr): EmbedOptions {
  const lb = (attr("data-lightbox") ?? "").trim().toLowerCase();
  return {
    columns: parseBoundedInt(attr("data-columns"), 1, 12),
    columnsTablet: parseBoundedInt(attr("data-columns-tablet"), 1, 12),
    columnsMobile: parseBoundedInt(attr("data-columns-mobile"), 1, 12),
    gap: parseBoundedInt(attr("data-gap"), 0, MAX_GAP),
    ...parseLook(attr),
    gutter: parseBoundedInt(attr("data-gutter"), 0, MAX_GAP),
    ratio: parseRatio(attr("data-ratio")),
    ratioOriginal: (attr("data-ratio") ?? "").trim().toLowerCase() === "original",
    captions: oneOf(CAPTIONS, attr("data-captions"), "off"),
    duotone: parseDuotone(attr("data-duotone")),
    sort: sortOf(attr("data-sort")),
    perPage: parseBoundedInt(attr("data-per-page"), 1, 500),
    loadMore: parseFlag(attr("data-load-more"), true),
    linkTo: LINK_TOS.find((x) => x === (attr("data-link-to") ?? "").trim().toLowerCase()),
    linkNewTab: parseFlag(attr("data-link-new-tab"), true),
    lightbox: !(lb === "off" || lb === "false" || lb === "0" || lb === "no"),
    imageText: parseImageText(attr("data-image-text")),
    badge: parseFlag(attr("data-badge"), true),
    exclude: new Set(
      (attr("data-exclude") ?? "")
        .split(/[\s,]+/)
        .map((s) => s.trim())
        .filter(Boolean),
    ),
  };
}

/** The caption override replaces the whole caption line (title and caption). */
function withText(p: EmbedPhoto, t?: ImageText): EmbedPhoto {
  const o = t?.get(p.id);
  if (!o) return p;
  return { ...p, ...(o.caption ? { title: "", caption: o.caption } : {}), ...(o.alt ? { alt: o.alt } : {}) };
}

/** Drops excluded ids, then orders. Never mutates the input. */
export function selectPhotos(photos: EmbedPhoto[], o: EmbedOptions, rand: () => number = Math.random): EmbedPhoto[] {
  const out = photos.filter((p) => !o.exclude.has(p.id)).map((p) => withText(p, o.imageText));
  if (o.sort === "reverse") out.reverse();
  else if (o.sort === "title") out.sort((a, b) => (a.title || "").localeCompare(b.title || ""));
  else if (o.sort === "random") {
    for (let i = out.length - 1; i > 0; i--) {
      const j = Math.floor(rand() * (i + 1));
      [out[i], out[j]] = [out[j], out[i]];
    }
  }
  return out;
}

/** Fallback proportion for a photo without dimensions in the payload. */
const FALLBACK_ASPECT = 1.5;

/** A photo's width over height, for the justified rows of ratio "original". */
export function photoAspect(p: Pick<EmbedPhoto, "width" | "height">): number {
  return p.width > 0 && p.height > 0 ? Math.round((p.width / p.height) * 1000) / 1000 : FALLBACK_ASPECT;
}

/**
 * Inline style for the wrapper: custom properties only; empty when nothing was set.
 * `count` is the number of photos shown; a column count above it would leave empty tracks.
 */
export function cssVars(o: EmbedOptions, count = 0, layout = "grid"): string {
  const v: string[] = [];
  const cap = (n: number) => (count > 0 ? Math.min(n, count) : n);
  if (o.columns) v.push(`--cols:${cap(o.columns)}`);
  if (o.columnsTablet) v.push(`--cols-tablet:${cap(o.columnsTablet)}`);
  if (o.columnsMobile) v.push(`--cols-mobile:${cap(o.columnsMobile)}`);
  v.push(...lookVars(o, layout));
  if (o.ratioOriginal) v.push(`--orig:${count}`);
  else if (o.ratio) v.push(`--ratio:${o.ratio.w}/${o.ratio.h}`);
  return v.join(";");
}

const SVG_NS = "http://www.w3.org/2000/svg";

function svgEl(tag: string, attrs: Record<string, string>): SVGElement {
  const e = document.createElementNS(SVG_NS, tag);
  for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
  return e;
}

/** The filter's numbers, shared with the server renderer: the colour matrix and one table per channel (R, G, B). */
export function duotoneValues([dark, light]: [string, string]): { matrix: string; tables: string[] } {
  const chan = (s: string, i: number) => (parseInt(s.slice(1 + i * 2, 3 + i * 2), 16) / 255).toFixed(4);
  const luma = "0.2126 0.7152 0.0722 0 0";
  return {
    matrix: `${luma} ${luma} ${luma} 0 0 0 1 0`,
    tables: [0, 1, 2].map((i) => `${chan(dark, i)} ${chan(light, i)}`),
  };
}

/** Inline SVG holding a duotone filter (luminance mapped between two colours). No request. */
export function duotoneSvg(id: string, colours: [string, string]): SVGElement {
  const { matrix, tables } = duotoneValues(colours);
  const transfer = svgEl("feComponentTransfer", {});
  (["R", "G", "B"] as const).forEach((c, i) => {
    transfer.appendChild(svgEl(`feFunc${c}`, { type: "table", tableValues: tables[i] }));
  });
  const filter = svgEl("filter", { id, "color-interpolation-filters": "sRGB" });
  filter.append(svgEl("feColorMatrix", { type: "matrix", values: matrix }), transfer);
  const svg = svgEl("svg", { width: "0", height: "0", "aria-hidden": "true", style: "position:absolute" });
  svg.appendChild(filter);
  return svg;
}

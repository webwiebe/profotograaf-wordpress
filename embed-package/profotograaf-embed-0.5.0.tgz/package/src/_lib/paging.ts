// The pages of a gallery the server drew with a page size (#280): the photos after
// the first page are fetched once and each "Show more" click adds the next page.

import type { Masonry } from "./masonry";
import { parseOptions, photoAspect, selectPhotos, type EmbedOptions } from "./options";
import type { EmbedGallery, EmbedPhoto } from "./types";

/**
 * The server drew the first page and the "Show more" button. The photos after it
 * are fetched once, the same way mount() fetches a gallery, and each click adds the
 * next page with the tiles render() builds. The lightbox then walks the whole list.
 * If the payload does not come, the button goes away and the first page stays.
 */
export async function resumePaging(
  host: HTMLElement,
  root: ShadowRoot,
  g: EmbedGallery,
  more: HTMLButtonElement,
  place: Masonry | undefined,
  base: string,
  makeTile: (p: EmbedPhoto, i: number) => HTMLElement,
): Promise<void> {
  const o = parseOptions((n) => host.getAttribute(n));
  const list = root.querySelector<HTMLElement>(".pf > .gallery > .photos");
  const per = o.perPage;
  if (!list || !per) return;
  const loading = fetchPhotos(host, base, o);
  let shown = list.querySelectorAll(".tile").length;
  // The root's click handler opens the lightbox for every tile, so these tiles open nothing themselves.
  const add = (t: HTMLElement, p: EmbedPhoto) => (place ? place.add(placement(t, p, o)) : list.appendChild(t));
  // A click that comes before the photos do waits for them.
  more.addEventListener("click", async () => {
    const photos = await loading;
    const end = Math.min(shown + per, photos.length);
    const added: HTMLElement[] = [];
    for (; shown < end; shown++) {
      added.push(makeTile(photos[shown], shown));
      add(added[added.length - 1], photos[shown]);
    }
    more.hidden = shown >= photos.length;
    focusTile(added[0]);
  });
  const photos = await loading;
  if (photos.length <= shown) return void (more.hidden = true);
  g.photos = photos;
}

/** The gallery's photos as the client would list them, or none when the payload does not come. */
export async function fetchPhotos(host: HTMLElement, base: string, o: EmbedOptions): Promise<EmbedPhoto[]> {
  const id = encodeURIComponent(host.getAttribute("data-profotograaf-gallery") || "");
  try {
    const res = await fetch(`${base}/api/v1/embed/galleries/${id}`, { credentials: "omit", referrerPolicy: "no-referrer" });
    return res.ok ? selectPhotos(((await res.json()) as EmbedGallery).photos ?? [], o) : [];
  } catch {
    return [];
  }
}

function placement(el: HTMLElement, p: EmbedPhoto, o: EmbedOptions) {
  return {
    el,
    ar: o.ratio ? o.ratio.w / o.ratio.h : photoAspect(p),
    below: o.captions === "below" && el.matches(".item"),
    narrowBelow: o.captions === "overlay" && el.matches(".ov"),
  };
}

function focusTile(first: HTMLElement | undefined): void {
  const target = first?.matches(".tile") ? first : first?.querySelector<HTMLElement>(".tile");
  if (!target) return;
  if (!target.matches("a, button")) target.tabIndex = -1;
  target.focus();
}

// Masonry placement (#2340). CSS multi-column fills one column top to bottom,
// which leaves ragged columns and puts the newest photos in column one. This
// places photos in row order, each into the currently shortest column, from the
// width and height in the payload: no image has to load, so nothing shifts.

import { columnGap, rowGap } from "./look";
import type { EmbedOptions } from "./options";

/** Target column width when no column count is set. */
const TARGET_COL = 220;
/** Container widths at or below which the tablet and phone counts apply. */
const TABLET_MAX = 900;
const PHONE_MAX = 600;
/** Phones show two masonry columns unless data-columns-mobile says otherwise. */
const PHONE_DEFAULT = 2;
/** Space a caption below a tile takes, in px, when the layout shows one. */
const CAPTION_PX = 30;
/** Tiles narrower than this move an overlay caption below the tile (the container query in css.ts). */
const NARROW_TILE_PX = 240;
/** Space a two-line caption below a narrow tile takes, in px. */
const NARROW_CAPTION_PX = 44;
/** A host this close to the viewport width counts as full width. */
const FULL_WIDTH_SLACK = 4;

type ColumnOptions = Pick<EmbedOptions, "columns" | "columnsTablet" | "columnsMobile" | "gap" | "gapColumn">;

/** How many columns fit a container `width` wide, never more than there are photos. */
export function masonryColumns(width: number, o: ColumnOptions, count: number): number {
  const n = width <= PHONE_MAX ? phoneColumns(o) : widerColumns(width, o, columnGap(o));
  return Math.max(1, Math.min(n, count > 0 ? count : n));
}

/** Phones take the mobile count, else the tablet or desktop count capped at the phone default. */
function phoneColumns(o: ColumnOptions): number {
  return o.columnsMobile ?? Math.min(o.columnsTablet ?? o.columns ?? PHONE_DEFAULT, PHONE_DEFAULT);
}

/** Tablets use an explicit count when one is set; otherwise columns fill the width at the target size. */
function widerColumns(width: number, o: ColumnOptions, gap: number): number {
  if (width <= TABLET_MAX && (o.columnsTablet ?? o.columns)) return o.columnsTablet ?? Math.min(o.columns ?? 3, 3);
  return o.columns ?? Math.floor((width + gap) / (TARGET_COL + gap));
}

/** Column index per item: each item goes to the shortest column so far; ties go to the leftmost. */
export function placeShortest(heights: number[], cols: number): number[] {
  const sums = Array.from({ length: Math.max(1, cols) }, () => 0);
  return heights.map((h) => {
    let best = 0;
    for (let c = 1; c < sums.length; c++) if (sums[c] < sums[best]) best = c;
    sums[best] += h;
    return best;
  });
}

export interface MasonryItem {
  el: HTMLElement;
  /** Width over height of the tile. */
  ar: number;
  /** A caption sits below the tile. */
  below: boolean;
  /** An overlay caption that moves below the tile when the tile is narrower than NARROW_TILE_PX. */
  narrowBelow?: boolean;
}

/** Height a caption adds under a tile `colW` wide: 0 when it overlays the photo. */
export function captionHeight(it: Pick<MasonryItem, "below" | "narrowBelow">, colW: number): number {
  if (it.below) return CAPTION_PX;
  return it.narrowBelow && colW < NARROW_TILE_PX ? NARROW_CAPTION_PX : 0;
}

export interface Masonry {
  add(item: MasonryItem): void;
  relayout(): void;
}

/** Fills `list` with column elements and keeps the placement current as `add` and `relayout` are called. */
export function masonry(list: HTMLElement, o: EmbedOptions, total: number): Masonry {
  const items: MasonryItem[] = [];
  let sig = "";
  let live = false;
  const relayout = () => {
    live = true;
    if (!items.length) return;
    const gap = columnGap(o);
    const width = list.clientWidth;
    const n = masonryColumns(width, o, total);
    const colW = Math.max(1, (width || 100) - gap * (n - 1)) / n;
    const at = placeShortest(
      items.map((it) => colW / it.ar + captionHeight(it, colW) + rowGap(o)),
      n,
    );
    const next = `${n}|${at.join(",")}`;
    if (next === sig) return;
    sig = next;
    const cols = Array.from({ length: n }, () => {
      const c = document.createElement("div");
      c.className = "mcol";
      return c;
    });
    items.forEach((it, i) => cols[at[i]].appendChild(it.el));
    list.replaceChildren(...cols);
  };
  return {
    add(item) {
      items.push(item);
      // Until the first relayout the list is not attached, so the initial batch is placed once.
      if (live) relayout();
    },
    relayout,
  };
}

/** Full width: the host is as wide as the viewport, so tiles would touch the screen edge. */
export function isFullWidth(hostWidth: number, viewportWidth: number): boolean {
  return viewportWidth > 0 && hostWidth >= viewportWidth - FULL_WIDTH_SLACK;
}

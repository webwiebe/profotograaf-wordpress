// Whether the embed may send its one anonymous view beacon.

/** True when the visitor asked not to be measured. */
export function trackingDisabled(nav: Navigator = navigator, win: Window = window): boolean {
  const n = nav as Navigator & { msDoNotTrack?: string; globalPrivacyControl?: boolean };
  const w = win as Window & { doNotTrack?: string };
  return (
    n.doNotTrack === "1" ||
    n.doNotTrack === "yes" ||
    w.doNotTrack === "1" ||
    n.msDoNotTrack === "1" ||
    n.globalPrivacyControl === true
  );
}

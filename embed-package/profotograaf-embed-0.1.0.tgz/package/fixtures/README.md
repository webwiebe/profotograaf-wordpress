# Embed fixtures

Each `<name>.json` is a gallery payload (`gallery`) plus the host attributes (`attrs`) of one embed. Each `<name>.expected.html` is the markup the embed renders for it: the shadow tree, one element per line, without the stylesheet.

`web/src/public/embed/golden.test.ts` renders every fixture with the embed's own renderer and compares it with the expected file. The WordPress plugin renders the same fixtures on the server and must produce the same markup after normalization.

Refresh the expected files after an intended change:

```
cd web && npx vitest run -u src/public/embed/golden.test.ts
```

Review the diff of the `.expected.html` files in the pull request: it is the change to the markup contract. To add a case, add a `<name>.json` and run the command above.

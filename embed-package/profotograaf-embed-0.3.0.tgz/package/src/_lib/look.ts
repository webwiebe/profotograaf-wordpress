// Spacing, shape and hover options (#2399): gap per axis, pill corners, hover
// effect, frame and shadow. Every field is optional or has a neutral default,
// so an embed without these attributes renders as it did before they existed.

import type { EmbedOptions } from "./options";
import { hex, MAX_GAP, parseBoundedInt } from "./parse";

const HOVERS = ["none", "zoom", "grow"] as const;
const STRENGTHS = ["subtle", "strong"] as const;
const SHADOWS = ["none", "soft", "strong"] as const;

export interface Look {
  /** Space between rows; falls back to `gap`. */
  gapRow?: number;
  /** Space between columns; falls back to `gap`. */
  gapColumn?: number;
  /** Explicit corner radius in px; undefined keeps the default. */
  radius?: number;
  /** data-radius="full": 50% corners, honoured on square crops only. */
  radiusFull: boolean;
  hover: (typeof HOVERS)[number];
  hoverStrength: (typeof STRENGTHS)[number];
  /** A matte around each photo: colour and width in px (1 to 24). */
  frame?: { color: string; width: number };
  shadow: (typeof SHADOWS)[number];
}

type Attr = (name: string) => string | null;

function oneOf<T extends string>(list: readonly T[], v: string | null, fallback: T): T {
  const s = (v ?? "").trim().toLowerCase();
  return list.find((x) => x === s) ?? fallback;
}

/** "#ffffff,8": a colour, then a width of 0 to 24 px. Width 0 or any bad part means no frame. */
export function parseFrame(v: string | null): Look["frame"] {
  const parts = (v ?? "").trim().split(/[\s,]+/);
  if (parts.length !== 2) return undefined;
  const color = hex(parts[0]);
  const width = parseBoundedInt(parts[1].replace(/px$/i, ""), 0, 24);
  return color && width ? { color, width } : undefined;
}

export function parseLook(attr: Attr): Look {
  const r = (attr("data-radius") ?? "").trim().toLowerCase();
  return {
    gapRow: parseBoundedInt(attr("data-gap-row"), 0, MAX_GAP),
    gapColumn: parseBoundedInt(attr("data-gap-column"), 0, MAX_GAP),
    radius: parseBoundedInt(r, 0, 64),
    radiusFull: r === "full",
    hover: oneOf(HOVERS, attr("data-hover"), "zoom"),
    hoverStrength: oneOf(STRENGTHS, attr("data-hover-strength"), "subtle"),
    frame: parseFrame(attr("data-frame")),
    shadow: oneOf(SHADOWS, attr("data-shadow"), "none"),
  };
}

type Gaps = Pick<EmbedOptions, "gap" | "gapRow" | "gapColumn">;

/** Space between rows in px. */
export const rowGap = (o: Gaps): number => o.gapRow ?? o.gap ?? 8;
/** Space between columns in px. */
export const columnGap = (o: Gaps): number => o.gapColumn ?? o.gap ?? 8;

/** Full radius applies when every tile is a square: the grid's default crop, or a 1:1 data-ratio. */
export function isSquareCrop(o: Pick<EmbedOptions, "ratio" | "ratioOriginal">, layout: string): boolean {
  if (layout === "slideshow" || o.ratioOriginal) return false;
  if (!o.ratio) return layout === "grid";
  return o.ratio.w === o.ratio.h;
}

/** Custom properties for gap, radius and frame; entries at their default are left out. */
export function lookVars(o: EmbedOptions, layout: string): string[] {
  const v: string[] = [];
  if (o.gap !== undefined) v.push(`--gap:${o.gap}px`);
  if (o.gapRow !== undefined) v.push(`--gap-row:${o.gapRow}px`);
  if (o.gapColumn !== undefined) v.push(`--gap-col:${o.gapColumn}px`);
  const radius = radiusVar(o, layout);
  if (radius) v.push(radius);
  if (o.frame) v.push(`--frame-w:${o.frame.width}px`, `--frame-c:${o.frame.color}`);
  return v;
}

// radiusVar returns the --radius declaration, or "" when the default applies.
// Rounded corners would let the page show through where flush tiles meet, so
// touching tiles (no gap on either axis) square them unless a radius was asked for.
function radiusVar(o: EmbedOptions, layout: string): string {
  if (o.radiusFull && isSquareCrop(o, layout)) return "--radius:50%";
  const anyGap = o.gap !== undefined || o.gapRow !== undefined || o.gapColumn !== undefined;
  const flush = anyGap && rowGap(o) === 0 && columnGap(o) === 0;
  const radius = o.radius ?? (flush ? 0 : undefined);
  return radius === undefined ? "" : `--radius:${radius}px`;
}

/** Class names for the gallery wrapper; empty when every option is at its default. */
export function lookClasses(o: EmbedOptions, layout: string): string[] {
  const c: string[] = [];
  if (o.hover !== "zoom") c.push(`hv-${o.hover}`);
  if (o.hoverStrength === "strong" && o.hover !== "none") c.push("hs-strong");
  if (o.shadow !== "none") c.push(`sh-${o.shadow}`);
  if (o.radiusFull && isSquareCrop(o, layout)) c.push("rfull");
  return c;
}

# Markup contract

`markup.json` lists every host attribute, class and ARIA attribute the gallery embed uses. The hosted gallery pages and the WordPress plugin render the same markup.

## Change rules (owner decision on #2530)

- Within a major version the contract only grows. `majors/{n}.json` is the frozen snapshot of major `n`, and `web/src/public/embed/contract.test.ts` fails when `markup.json` drops a name the newest snapshot lists.
- A removal or a rename is a new major. Add `majors/{n+1}.json`, set `major` in `markup.json`, and keep serving the old major beside the new one (versioned endpoints, not in-place changes).
- The support window is 6 months. `wp-plugin-contract` covers every major inside it.
- A PR that adds a major carries the `breaking-change` label, a short note on why, and needs the owner's sign-off. The `Embed contract` workflow fails a PR that adds `majors/{n}.json` without the label.

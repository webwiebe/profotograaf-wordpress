# Changelog

Versions follow semver. The markup contract (`contract/markup.json`) only grows within a major version; a removal or rename is a new major (see `contract/README.md`).

## 0.2.0

- A server renderer may now draw the columns (`data-columns`, `-tablet`, `-mobile`), gap (`data-gap`, `-row`, `-column`), radius, shadow and hover (`data-hover`, `data-hover-strength`) options. They only set a class or a custom property, so a host div that uses them keeps its server-drawn shadow root and `embed.js` adopts it (#2789). With `data-hover="grow"` the outermost tile or figure carries the `u` class, as the client draws it.
- New fixtures: `look-columns`, `look-columns-capped`, `look-gap-radius`, `look-flush`, `look-radius-full`, `look-radius-full-masonry`, `look-shadow-hover`, `look-hover-none`, each with its `.expected.html` and `.server.html`.
- Still drawn by the client: `data-gutter`, `data-frame`, `data-duotone`, `data-ratio`, `data-image-text`, `data-link-to`, `data-link-new-tab`, `data-sort`, `data-exclude`, `data-per-page`, `data-load-more`.

## 0.1.1

- The API origin comes from a `data-platform` attribute on the script tag when it holds an absolute https origin, and from the script URL otherwise. A copy served from the WordPress plugin folder now reaches the platform (#2653). `contract/markup.json` lists the attribute in a new `script` section.

## 0.1.0

First packaged version (#2530).

- `dist/embed.js`: the gallery embed's interactive layer as one readable script with a source map. It adopts a server-drawn shadow root and draws the grid, masonry and slideshow layouts, the lightbox, favourites and proofing hooks itself when the host sends none.
- `src/`: the TypeScript the script is built from.
- `contract/markup.json` and `contract/majors/1.json`: the markup contract, major 1.
- `fixtures/`: gallery API responses with the expected markup (`*.expected.html`) and the server-drawn markup (`*.server.html`), for the WordPress plugin's parity test.

// embed.js: puts a Profotograaf gallery on any website (#1699).
//
//   <div data-profotograaf-gallery="{id}" data-layout="grid|masonry|slideshow">
//     (a platform layout name such as parallax is mapped to the nearest of those)
//     <a href="https://profotograaf.nl/share/g/slug">View the gallery</a>
//   </div>
//   <script async src="https://profotograaf.nl/share/embed/embed.js"></script>
//
// The script reads the public embed API, then renders inside a shadow root so
// the host page's CSS cannot reach it. Without JavaScript (or when the API
// answers anything but 200) the link written inside the div stays visible.
//
// No cookies, no third-party requests: every request goes to the origin the
// script was loaded from, with credentials omitted. One anonymous view beacon
// (source=embed + the host origin) is sent unless Do Not Track or Global
// Privacy Control is on.

import { drawnLayout, galleryFromMarkup } from "./_lib/adopt";
import { BREAKPOINTS, EMBED_CSS } from "./_lib/css";
import { bestSrc, lightbox } from "./_lib/lightbox";
import { linkHref } from "./_lib/link";
import { resumePaging } from "./_lib/paging";
import { resumeSlideshow } from "./_lib/resume-slides";
import { isFullWidth, masonry, type Masonry } from "./_lib/masonry";
import { resolveLayout, type DrawnLayout } from "./_lib/layouts";
import { badgeText, pickLocale, label } from "./_lib/i18n";
import { columnGap, lookClasses } from "./_lib/look";
import { cssVars, duotoneSvg, parseOptions, photoAspect, selectPhotos, type EmbedOptions } from "./_lib/options";
import { counterText, smallestSrc, stageRatio, usesCounter } from "./_lib/slideshow";
import type { EmbedGallery, EmbedPhoto } from "./_lib/types";

/** What every attribute resolves to when absent: today's output. */
const DEFAULTS: EmbedOptions = parseOptions(() => null);

const SELECTOR = "[data-profotograaf-gallery]";
type Layout = DrawnLayout;

/** True when the visitor asked not to be measured. */
export function trackingDisabled(nav: Navigator = navigator, win: Window = window): boolean {
  const n = nav as Navigator & { msDoNotTrack?: string; globalPrivacyControl?: boolean };
  const w = win as Window & { doNotTrack?: string };
  return (
    n.doNotTrack === "1" ||
    n.doNotTrack === "yes" ||
    w.doNotTrack === "1" ||
    n.msDoNotTrack === "1" ||
    n.globalPrivacyControl === true
  );
}

/** An absolute https origin ("https://host[:port]", one trailing slash allowed), else "". */
export function httpsOrigin(raw: string | null | undefined): string {
  try {
    const u = new URL(raw ?? "");
    const bare = u.pathname === "/" && !u.search && !u.hash && !u.username && !u.password;
    return u.protocol === "https:" && bare ? u.origin : "";
  } catch {
    return "";
  }
}

/**
 * The origin every API call goes to. A data-platform attribute on the script
 * tag wins, so a copy served from somewhere else (the WordPress plugin folder)
 * still reaches the platform; without one it is the origin that served this script.
 */
export function apiBase(doc: Document = document): string {
  const cs = doc.currentScript as HTMLScriptElement | null;
  const el = cs?.src ? cs : doc.querySelector<HTMLScriptElement>('script[src*="/share/embed/embed"], script[data-platform]');
  const declared = httpsOrigin(el?.getAttribute("data-platform"));
  if (declared) return declared;
  try {
    return new URL(el?.src ?? "").origin;
  } catch {
    return "";
  }
}

export function pickLayout(attr: string | null, fallback: string): Layout {
  return resolveLayout(attr, fallback);
}

function el<K extends keyof HTMLElementTagNameMap>(tag: K, cls?: string, text?: string): HTMLElementTagNameMap[K] {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}

export function photoAlt(p: EmbedPhoto, g: EmbedGallery, i: number): string {
  return p.alt || p.title || p.caption || `${g.title} ${i + 1}`;
}

/** srcset from the stable image URLs, widest last. */
export function srcset(p: EmbedPhoto, squareOnly: boolean): string {
  const ratio = p.width && p.height ? p.width / p.height : 0;
  return p.images
    .filter((im) => squareOnly || im.variant !== "thumb" || (ratio && Math.abs(im.width / im.height - ratio) < 0.03))
    .map((im) => `${im.url} ${im.width}w`)
    .join(", ");
}

export const bestUrl = bestSrc;

function thumb(p: EmbedPhoto, g: EmbedGallery, i: number, layout: Layout): HTMLImageElement {
  const img = el("img");
  img.alt = photoAlt(p, g, i);
  img.src = bestUrl(p);
  const grid = layout === "grid";
  const set = srcset(p, grid);
  if (set) {
    img.srcset = set;
    img.sizes = grid ? "(max-width: 600px) 50vw, 33vw" : "(max-width: 600px) 100vw, 50vw";
  }
  if (p.width && p.height) {
    img.width = p.width;
    img.height = p.height;
  }
  // As attributes, so the markup a server draws and the markup drawn here serialize the same.
  img.setAttribute("loading", i === 0 && layout === "slideshow" ? "eager" : "lazy");
  img.setAttribute("decoding", "async");
  img.draggable = false;
  return img;
}

function captionText(p: EmbedPhoto): string {
  return [p.title, p.caption].filter(Boolean).join(" - ");
}

export { linkHref };

/** The element a tile is drawn in: a button that opens the lightbox, a link, or an inert box. */
function tileShell(p: EmbedPhoto, g: EmbedGallery, i: number, open: (i: number) => void, o: EmbedOptions): HTMLElement {
  if (o.lightbox) {
    const b = el("button", "tile");
    b.type = "button";
    b.addEventListener("click", () => open(i));
    b.setAttribute("aria-label", photoAlt(p, g, i));
    return b;
  }
  const href = linkHref(p, g, o.linkTo);
  if (href) {
    const a = el("a", "tile");
    a.href = href;
    if (o.linkNewTab) {
      a.target = "_blank";
      a.rel = "noopener noreferrer";
    }
    a.setAttribute("aria-label", photoAlt(p, g, i));
    return a;
  }
  // An explicit link target that resolves to nothing (none, or a site the owner
  // has not published) is an inert box. Without one, today's plain button stays.
  if (o.linkTo) return el("div", "tile static");
  const b = el("button", "tile static");
  b.type = "button";
  b.setAttribute("aria-label", photoAlt(p, g, i));
  return b;
}

/** Wraps `b` with its caption: a figure for below and overlay captions, `b` itself (overlay inside it) or untouched when there is none. */
function captioned(b: HTMLElement, p: EmbedPhoto, layout: Layout, o: EmbedOptions): HTMLElement {
  const text = o.captions === "off" ? "" : captionText(p);
  if (!text) return b;
  if (o.captions === "overlay" && layout === "slideshow") {
    b.appendChild(el("span", "cap", text));
    return b;
  }
  if (o.captions === "below") {
    const fig = el("figure", "item");
    fig.append(b, el("figcaption", "below", text));
    return fig;
  }
  // Overlay captions sit in a sibling of the tile so a narrow tile can move them below (a container query on the item).
  const fig = el("figure", "item ov");
  fig.append(b, el("figcaption", "cap", text));
  return fig;
}

function tile(
  p: EmbedPhoto,
  g: EmbedGallery,
  i: number,
  layout: Layout,
  open: (i: number) => void,
  o: EmbedOptions = DEFAULTS,
): HTMLElement {
  const b = tileShell(p, g, i, open, o);
  // Original ratio shows uncropped photos, so the square thumb crops stay out of the srcset.
  b.appendChild(thumb(p, g, i, o.ratioOriginal ? "masonry" : layout));
  if (o.ratioOriginal) b.style.setProperty("--ar", String(photoAspect(p)));
  const fig = captioned(b, p, layout, o);
  // The grow hover scales this element as a whole (tile and caption), so it gets a hook.
  if (o.hover === "grow") fig.classList.add("u");
  if (fig === b) return b;
  if (o.ratioOriginal) fig.style.setProperty("--ar", String(photoAspect(p)));
  return fig;
}

function slideshow(g: EmbedGallery, open: (i: number) => void, o: EmbedOptions): HTMLElement {
  const box = el("div", "slides");
  box.setAttribute("role", "group");
  box.setAttribute("aria-roledescription", "carousel");
  box.setAttribute("aria-label", g.title);
  const frame = el("div", "frame");
  const stage = el("div", "stage");
  const total = g.photos.length;
  const counter = usesCounter(total);
  const pager = el("div", counter ? "count" : "dots");
  if (counter) pager.setAttribute("aria-live", "polite");
  let cur = 0;
  const go = (n: number) => {
    cur = (n + total) % total;
    const p = g.photos[cur];
    stage.style.setProperty("--pr", stageRatio(p));
    const kids: HTMLElement[] = [tile(p, g, cur, "slideshow", open, o)];
    if (!o.ratio) {
      // Behind a photo that does not fill the stage: a blurred copy instead of flat black.
      const bg = el("img", "bg");
      bg.alt = "";
      bg.setAttribute("aria-hidden", "true");
      bg.src = smallestSrc(p);
      kids.unshift(bg);
    }
    stage.replaceChildren(...kids);
    if (counter) pager.textContent = counterText(cur, total);
    else pager.querySelectorAll("button").forEach((d, k) => d.setAttribute("aria-current", String(k === cur)));
  };
  const nav = (dir: -1 | 1, label: string) => {
    const b = el("button", `nav ${dir < 0 ? "prev" : "next"}`, dir < 0 ? "\u2039" : "\u203a");
    b.type = "button";
    b.setAttribute("aria-label", label);
    b.addEventListener("click", () => go(cur + dir));
    return b;
  };
  if (!counter) {
    g.photos.forEach((_, k) => {
      const d = el("button", "dot");
      d.type = "button";
      d.setAttribute("aria-label", `${k + 1} / ${total}`);
      d.addEventListener("click", () => go(k));
      pager.appendChild(d);
    });
  }
  let x0 = 0;
  stage.addEventListener("pointerdown", (e) => (x0 = e.clientX));
  stage.addEventListener("pointerup", (e) => {
    const dx = e.clientX - x0;
    if (Math.abs(dx) > 50) go(cur + (dx < 0 ? 1 : -1));
  });
  box.addEventListener("keydown", (e) => {
    if (e.key === "ArrowLeft") go(cur - 1);
    else if (e.key === "ArrowRight") go(cur + 1);
  });
  frame.append(stage, nav(-1, label("prev")), nav(1, label("next")));
  box.append(frame, pager);
  go(0);
  return box;
}

function badge(g: EmbedGallery, o: EmbedOptions): HTMLElement | null {
  if (!o.badge || !g.badge?.show) return null;
  const a = el("a", g.badge.prominent ? "badge prominent" : "badge", badgeText());
  a.href = g.badge.url;
  a.target = "_blank";
  a.rel = "noopener";
  return a;
}

/** Photos of a non-slideshow layout, in pages of `data-per-page` with a "show more" button. */
function paged(add: (t: HTMLElement, p: EmbedPhoto) => void, g: EmbedGallery, layout: Layout, open: (i: number) => void, o: EmbedOptions) {
  const per = o.perPage ?? g.photos.length;
  let shown = 0;
  const more = el("button", "more", label("more"));
  more.type = "button";
  const next = (moveFocus: boolean) => {
    const end = Math.min(shown + per, g.photos.length);
    let first: HTMLElement | undefined;
    for (; shown < end; shown++) {
      const t = tile(g.photos[shown], g, shown, layout, open, o);
      first ??= t;
      add(t, g.photos[shown]);
    }
    more.hidden = shown >= g.photos.length;
    if (!moveFocus || !first) return;
    // The clicked button is about to vanish; keyboard focus would fall to the page.
    const target = first.matches(".tile") ? first : first.querySelector<HTMLElement>(".tile");
    if (!target) return;
    if (!target.matches("a, button")) target.tabIndex = -1;
    target.focus();
  };
  more.addEventListener("click", () => next(true));
  next(false);
  return more;
}

/** Keeps the full-width gutter and the masonry columns current while the host resizes. */
function watch(root: ShadowRoot, pf: HTMLElement, o: EmbedOptions, place: Masonry | undefined): void {
  const host = root.host as HTMLElement | undefined;
  if (!host) return place?.relayout();
  const sync = () => {
    const full = isFullWidth(host.getBoundingClientRect().width, document.documentElement.clientWidth);
    if (full) pf.style.setProperty("--gutter", `${o.gutter ?? columnGap(o)}px`);
    else pf.style.removeProperty("--gutter");
    place?.relayout();
  };
  sync();
  if (typeof ResizeObserver !== "undefined") new ResizeObserver(sync).observe(host);
}

/** Builds the gallery DOM for one layout. Pure apart from the shadow root it fills. */
/** Builds the grid or masonry photo list inside `wrap`; returns the masonry placer when there is one. */
function photoList(wrap: HTMLElement, g: EmbedGallery, layout: Layout, open: (i: number) => void, o: EmbedOptions): Masonry | undefined {
  const list = el("div", "photos");
  wrap.appendChild(list);
  const place = layout === "masonry" ? masonry(list, o, g.photos.length) : undefined;
  const add = (t: HTMLElement, p: EmbedPhoto) => {
    if (!place) return void list.appendChild(t);
    place.add({ el: t, ar: o.ratio ? o.ratio.w / o.ratio.h : photoAspect(p), below: o.captions === "below" && t.matches(".item"), narrowBelow: o.captions === "overlay" && t.matches(".ov") });
  };
  if (o.perPage && o.loadMore) wrap.appendChild(paged(add, g, layout, open, o));
  else g.photos.forEach((p, i) => add(tile(p, g, i, layout, open, o), p));
  return place;
}

export function render(root: ShadowRoot, gal: EmbedGallery, layout: Layout, o: EmbedOptions = DEFAULTS): void {
  let g = o === DEFAULTS ? gal : { ...gal, photos: selectPhotos(gal.photos, o) };
  // Per-page without the button is the first page only. The lightbox walks g.photos, so
  // the photos that are never shown are dropped here rather than hidden.
  const firstPageOnly = !!o.perPage && !o.loadMore && layout !== "slideshow";
  if (firstPageOnly) g = { ...g, photos: g.photos.slice(0, o.perPage) };
  const style = el("style");
  style.textContent = EMBED_CSS;
  const pf = el("div", "pf");
  const wrap = el("div", ["gallery", layout, ...(o.duotone ? ["duo"] : []), ...lookClasses(o, layout)].join(" "));
  pf.appendChild(wrap);
  const vars = cssVars(o, g.photos.length, layout);
  if (vars) wrap.setAttribute("style", vars);
  const open = (i: number) => lightbox(root, g, i);
  let place: Masonry | undefined;
  if (layout === "slideshow") wrap.appendChild(slideshow(g, open, o));
  else place = photoList(wrap, g, layout, open, o);
  const b = badge(g, o);
  root.replaceChildren(style, pf);
  watch(root, pf, o, place);
  if (o.duotone) root.appendChild(duotoneSvg("pf-duo", o.duotone));
  if (b) root.appendChild(b);
}

function beacon(base: string, id: string): void {
  if (trackingDisabled() || !navigator.sendBeacon) return;
  const body = new URLSearchParams({ gallery: id, source: "embed", origin: location.origin });
  // A form-encoded Blob is a CORS-safelisted content type: no preflight. A bare
  // string would go out as text/plain and the endpoint would record nothing.
  navigator.sendBeacon(`${base}/share/embed/view`, new Blob([body.toString()], { type: "application/x-www-form-urlencoded" }));
}

function onceVisible(host: Element, fn: () => void): void {
  if (!("IntersectionObserver" in window)) return fn();
  const io = new IntersectionObserver((es) => {
    if (es.some((e) => e.isIntersecting)) {
      io.disconnect();
      fn();
    }
  });
  io.observe(host);
}

export type EmbedState = "drawn" | "empty" | "error";

/** Tells the host page how the embed ended: a data-pf-state attribute plus a bubbling event. */
function setState(host: HTMLElement, state: EmbedState, layout?: Layout): void {
  host.setAttribute("data-pf-state", state);
  if (layout) {
    host.setAttribute("data-pf-layout", layout);
    host.setAttribute("data-pf-breakpoints", BREAKPOINTS.join(","));
  }
  host.dispatchEvent(new CustomEvent("profotograaf:state", { bubbles: true, detail: layout ? { state, layout } : { state } }));
}

/** A shadow root that came drawn from the server is kept, and the lightbox opens from its markup. A paged gallery fetches its photos once, for the pages after the drawn one (#280). */
function adopt(host: HTMLElement, base: string): boolean {
  const root = host.shadowRoot;
  const layout = drawnLayout(root);
  if (!root || !layout) return false;
  const g = galleryFromMarkup(root, host.getAttribute("aria-label") || "");
  const openFromMarkup = (e: Event) => {
    const t = (e.target as Element).closest?.(".tile");
    const tiles = [...root.querySelectorAll(".tile")].filter((x) => x.querySelector("img"));
    const i = t ? tiles.indexOf(t) : -1;
    // Links and the inert tiles of lightbox="off" open nothing, as in render().
    if (i >= 0 && !t?.matches("a, .static")) lightbox(root, g, i);
  };
  // A slideshow is replaced by the script's own once the photos are in; its tiles open the lightbox themselves.
  if (layout !== "slideshow") root.addEventListener("click", openFromMarkup);
  else void resumeSlideshow(host, root, g, base, () => slideshow(g, (i) => lightbox(root, g, i), parseOptions((n) => host.getAttribute(n))), () => root.addEventListener("click", openFromMarkup));
  const place = placeDrawn(root, host, g, layout === "masonry");
  setState(host, "drawn", layout as Layout);
  const more = root.querySelector<HTMLButtonElement>(".pf > .gallery > .more");
  if (more && !more.hidden) void resumePaging(host, root, g, more, place, base, (p, i) => tile(p, g, i, layout as Layout, () => {}, parseOptions((n) => host.getAttribute(n))));
  return true;
}

/**
 * A server draws masonry as one ordered list; the columns need widths, so they
 * are placed here from the sizes in the markup, with the same placer render() uses.
 * Either layout then follows the host width for the full-width gutter.
 */
function placeDrawn(root: ShadowRoot, host: HTMLElement, g: EmbedGallery, columns: boolean): Masonry | undefined {
  const list = root.querySelector<HTMLElement>(".pf > .gallery > .photos");
  const pf = root.querySelector<HTMLElement>(".pf");
  if (!pf) return undefined;
  const o = parseOptions((n) => host.getAttribute(n));
  if (!list || !columns) return void watch(root, pf, o, undefined);
  const tiles = [...list.children] as HTMLElement[];
  const place = masonry(list, o, tiles.length);
  tiles.forEach((t, i) => {
    const ar = o.ratio ? o.ratio.w / o.ratio.h : photoAspect(g.photos[i] ?? { width: 0, height: 0 });
    place.add({ el: t, ar, below: o.captions === "below" && t.matches(".item"), narrowBelow: o.captions === "overlay" && t.matches(".ov") });
  });
  watch(root, pf, o, place);
  return place;
}

async function mount(host: HTMLElement, base: string): Promise<void> {
  if (host.hasAttribute("data-pf-ready")) return;
  host.setAttribute("data-pf-ready", "");
  const id = host.getAttribute("data-profotograaf-gallery") || "";
  if (!id) return setState(host, "error");
  if (adopt(host, base)) return;
  let drawn = false;
  try {
    const res = await fetch(`${base}/api/v1/embed/galleries/${encodeURIComponent(id)}`, {
      credentials: "omit",
      referrerPolicy: "no-referrer",
    });
    if (!res.ok) return setState(host, "error");
    const g = (await res.json()) as EmbedGallery;
    if (!g.photos?.length) return setState(host, "empty");
    const opts = parseOptions((n) => host.getAttribute(n));
    if (!selectPhotos(g.photos, opts).length) return setState(host, "empty");
    pickLocale(host.getAttribute("lang") || document.documentElement.lang);
    const root = host.shadowRoot ?? host.attachShadow({ mode: "open" });
    const layout = pickLayout(host.getAttribute("data-layout"), g.layout);
    render(root, g, layout, opts);
    drawn = true;
    setState(host, "drawn", layout);
    onceVisible(host, () => beacon(base, g.id));
  } catch {
    // The fallback link inside the div stays.
    if (!drawn) setState(host, "error");
  }
}

export function scan(base = apiBase()): void {
  const hosts = document.querySelectorAll<HTMLElement>(SELECTOR);
  if (!base) {
    // No origin to call: no host can be drawn, and each one says so once.
    hosts.forEach((h) => {
      if (h.hasAttribute("data-pf-state")) return;
      h.setAttribute("data-pf-ready", "");
      setState(h, "error");
    });
    return;
  }
  hosts.forEach((h) => void mount(h, base));
}

function start(): void {
  const base = apiBase();
  scan(base);
  if (!base) return;
  // Page builders inject markup late; pick those up too.
  if (!("MutationObserver" in window)) return;
  let queued = false;
  new MutationObserver(() => {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => {
      queued = false;
      scan(base);
    });
  }).observe(document.documentElement, { childList: true, subtree: true });
}

if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
else start();

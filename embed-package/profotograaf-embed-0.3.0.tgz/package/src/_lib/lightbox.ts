// Keyboard and swipe lightbox. Lives in the gallery's shadow root, traps focus
// while open, closes on Escape and hands focus back to the tile that opened it.

import { label } from "./i18n";
import type { EmbedGallery, EmbedPhoto } from "./types";

const SWIPE_PX = 50;

function btn(cls: string, label: string, glyph: string): HTMLButtonElement {
  const b = document.createElement("button");
  b.type = "button";
  b.className = cls;
  b.setAttribute("aria-label", label);
  b.textContent = glyph;
  return b;
}

/** The largest image: the plain src and the lightbox photo. */
export function bestSrc(p: EmbedPhoto): string {
  const web = p.images.find((im) => im.variant === "web") ?? p.images[p.images.length - 1];
  return web ? web.url : "";
}

interface Parts {
  dlg: HTMLDivElement;
  close: HTMLButtonElement;
  prev: HTMLButtonElement;
  next: HTMLButtonElement;
  count: HTMLDivElement;
  fig: HTMLElement;
  img: HTMLImageElement;
  title: HTMLDivElement;
  text: HTMLDivElement;
}

function div(cls: string): HTMLDivElement {
  const d = document.createElement("div");
  d.className = cls;
  return d;
}

function buildParts(g: EmbedGallery): Parts {
  const dlg = div("lb");
  dlg.setAttribute("role", "dialog");
  dlg.setAttribute("aria-modal", "true");
  dlg.setAttribute("aria-label", g.title);
  const close = btn("x", label("close"), "×");
  const prev = btn("p", label("prev"), "‹");
  const next = btn("n", label("next"), "›");
  const count = div("count");
  const fig = document.createElement("figure");
  const img = document.createElement("img");
  const cap = document.createElement("figcaption");
  const title = div("title");
  const text = div("");
  cap.append(title, text);
  fig.append(img, cap);
  dlg.append(close, count, fig, prev, next);
  return { dlg, close, prev, next, count, fig, img, title, text };
}

function trapTab(root: ShadowRoot, parts: Parts, e: KeyboardEvent): void {
  const items = [parts.close, parts.prev, parts.next].filter((b) => !b.hidden);
  const first = items[0];
  const last = items[items.length - 1];
  const active = root.activeElement as HTMLButtonElement | null;
  const outside = !active || !items.includes(active);
  if (outside || (e.shiftKey && active === first)) {
    e.preventDefault();
    (e.shiftKey && !outside ? last : first).focus();
  } else if (!e.shiftKey && active === last) {
    e.preventDefault();
    first.focus();
  }
}

interface Controls {
  show: (i: number) => void;
  step: (d: number) => void;
  shut: () => void;
  tab: (e: KeyboardEvent) => void;
}

function onKey(c: Controls, e: KeyboardEvent): void {
  const handlers: Record<string, () => void> = {
    Escape: () => {
      e.preventDefault();
      c.shut();
    },
    ArrowLeft: () => c.step(-1),
    ArrowRight: () => c.step(1),
    Tab: () => c.tab(e),
  };
  handlers[e.key]?.();
}

function wireSwipe(dlg: HTMLElement, n: number, step: (d: number) => void): void {
  let x0 = 0;
  dlg.addEventListener("pointerdown", (e) => (x0 = e.clientX));
  dlg.addEventListener("pointerup", (e) => {
    const dx = e.clientX - x0;
    if (Math.abs(dx) > SWIPE_PX && n > 1) step(dx < 0 ? 1 : -1);
  });
}

function wire(parts: Parts, n: number, c: Controls): void {
  const { dlg, close, prev, next, fig } = parts;
  dlg.addEventListener("keydown", (e) => onKey(c, e));
  close.addEventListener("click", c.shut);
  prev.addEventListener("click", () => c.step(-1));
  next.addEventListener("click", () => c.step(1));
  dlg.addEventListener("click", (e) => {
    if (e.target === dlg || e.target === fig) c.shut();
  });
  wireSwipe(dlg, n, c.step);
}

function renderPhoto(parts: Parts, g: EmbedGallery, cur: number): void {
  const n = g.photos.length;
  const p = g.photos[cur];
  parts.img.src = bestSrc(p);
  parts.img.width = p.width;
  parts.img.height = p.height;
  parts.img.alt = p.alt || p.title || p.caption || `${g.title} ${cur + 1}`;
  parts.title.textContent = p.title;
  parts.text.textContent = p.caption;
  parts.count.textContent = `${cur + 1} / ${n}`;
  parts.prev.hidden = parts.next.hidden = n < 2;
  // Warm the neighbours so arrow keys feel instant.
  for (const k of [cur + 1, cur - 1]) new Image().src = bestSrc(g.photos[(k + n) % n]);
}

export function lightbox(root: ShadowRoot, g: EmbedGallery, start: number): void {
  if (root.querySelector(".lb")) return;
  const opener = (root.activeElement as HTMLElement | null) ?? null;
  const n = g.photos.length;
  const parts = buildParts(g);
  const prevOverflow = document.body.style.overflow;
  let cur = start;

  const show = (i: number) => {
    cur = (i + n) % n;
    renderPhoto(parts, g, cur);
  };
  const shut = () => {
    parts.dlg.remove();
    document.body.style.overflow = prevOverflow;
    opener?.focus?.();
  };
  const controls: Controls = {
    show,
    step: (d) => show(cur + d),
    shut,
    tab: (e) => trapTab(root, parts, e),
  };
  wire(parts, n, controls);

  document.body.style.overflow = "hidden";
  root.appendChild(parts.dlg);
  show(start);
  parts.close.focus();
}

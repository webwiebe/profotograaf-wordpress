// Where a tile links when the lightbox is off (#2859). Shared by the client
// renderer and the server renderer so both resolve the same href.

import { bestSrc } from "./lightbox";
import type { EmbedOptions } from "./options";
import type { EmbedGallery, EmbedPhoto } from "./types";

/** Only http(s) links, absolute or relative: a value from the API is never put into an href unchecked. */
export function webHref(v: string | undefined, base: string = location.href): string {
  if (!v) return "";
  try {
    const scheme = new URL(v, base).protocol;
    return scheme === "http:" || scheme === "https:" ? v : "";
  } catch {
    return "";
  }
}

/** Where a tile links when the lightbox is off: "" for none, or when the payload lacks the target. */
export function linkHref(p: EmbedPhoto, g: EmbedGallery, linkTo: EmbedOptions["linkTo"], base?: string): string {
  if (linkTo === "file") return webHref(bestSrc(p), base);
  if (linkTo === "page") return webHref(p.url, base) || webHref(g.url, base);
  if (linkTo === "site") return webHref(g.site_url, base);
  return "";
}

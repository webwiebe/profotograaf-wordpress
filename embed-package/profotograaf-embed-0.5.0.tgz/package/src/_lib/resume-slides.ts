// A slideshow the server drew at its first slide (#2530): the stage, the arrows
// and the pager are in the markup, but only slide 1 is. The photos are fetched
// once, the same way mount() fetches a gallery, and the interactive slideshow
// replaces the drawn one. Slide 1 is the same in both, so nothing moves.

import { fetchPhotos } from "./paging";
import { parseOptions } from "./options";
import type { EmbedGallery } from "./types";

/**
 * `build` returns the slideshow element for `g.photos`, which holds the fetched
 * photos by then. When the payload does not come, the drawn
 * first slide stays.
 */
export async function resumeSlideshow(
  host: HTMLElement,
  root: ShadowRoot,
  g: EmbedGallery,
  base: string,
  build: () => HTMLElement,
): Promise<void> {
  const drawn = root.querySelector(".pf > .gallery > .slides");
  const photos = await fetchPhotos(host, base, parseOptions((n) => host.getAttribute(n)));
  if (!drawn || !photos.length) return;
  g.photos = photos;
  drawn.replaceWith(build());
}

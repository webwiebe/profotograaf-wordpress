// Slideshow decisions that do not touch the DOM: which pager to draw and what
// shape the stage takes for a photo.

import type { EmbedPhoto } from "./types";

/** Up to this many photos get one dot each; above it a "3 / 20" counter replaces them. */
export const DOT_LIMIT = 12;

/** Shape of the stage when a photo has no usable size. */
const FALLBACK_RATIO = "3/2";

export function usesCounter(count: number): boolean {
  return count > DOT_LIMIT;
}

export function counterText(index: number, count: number): string {
  return `${index + 1} / ${count}`;
}

/** The CSS aspect-ratio for the stage: the photo's own width/height, or 3/2 when unknown. */
export function stageRatio(p: EmbedPhoto): string {
  return p.width > 0 && p.height > 0 ? `${p.width}/${p.height}` : FALLBACK_RATIO;
}

/** The smallest image of a photo: enough for a blurred backdrop. */
export function smallestSrc(p: EmbedPhoto): string {
  const sorted = [...p.images].sort((a, b) => a.width - b.width);
  return sorted[0]?.url ?? "";
}

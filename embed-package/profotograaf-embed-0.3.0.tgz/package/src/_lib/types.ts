// The embed API payload (docs/embed-api.md). Only the fields the script reads.

export interface EmbedImage {
  variant: string;
  url: string;
  width: number;
  height: number;
}

export interface EmbedPhoto {
  id: string;
  width: number;
  height: number;
  alt: string;
  title: string;
  caption: string;
  images: EmbedImage[];
  /** The photo's own page on the platform. */
  url?: string;
}

export interface EmbedGallery {
  id: string;
  title: string;
  layout: string;
  /** The drawn layout the server maps `layout` to. */
  embed_layout?: string;
  url: string;
  /** The owner's published portfolio; absent when there is none. */
  site_url?: string;
  badge?: { show: boolean; prominent: boolean; url: string };
  photos: EmbedPhoto[];
}

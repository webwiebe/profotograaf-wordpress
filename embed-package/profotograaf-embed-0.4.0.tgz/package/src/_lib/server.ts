// Server-side markup for the gallery embed (#2530): the same tree render()
// draws, as a declarative shadow root (<template shadowrootmode="open">). A
// server that cannot run the embed writes this next to the host div; embed.js
// then adopts it (adopt.ts) instead of fetching and redrawing. The WordPress
// plugin's PHP renderer is a port of this file and is held to the same fixtures.
//
// Only what a server can draw without measuring anything: grid and masonry (one
// ordered list, no columns), captions off, below or overlay, the lightbox tile
// or, with the lightbox off, a link or an inert tile, the badge, and the look:
// column counts, gap, gutter, radius, frame, ratio, shadow, hover and duotone,
// which reach the page as classes and custom properties of the stylesheet
// (#2789, #2859). The photo list is the one the client would draw: excluded ids
// dropped, caption and alt overrides applied, sorted. Everything else (a random
// order, the original ratio) returns null and the client draws it. A page size
// is drawn as its first page and the "Show more" button; the script keeps the
// drawn tiles on adoption and fetches the rest when the visitor asks for it (#280).

import { EMBED_CSS } from "./css";
import { badgeText, label, pickLocale } from "./i18n";
import { linkHref } from "./link";
import { lookClasses } from "./look";
import { cssVars, duotoneValues, parseOptions, selectPhotos, type EmbedOptions } from "./options";
import { resolveLayout } from "./layouts";
import type { EmbedGallery, EmbedPhoto } from "./types";

const SERVED_LAYOUTS = ["grid", "masonry"];
/** Options whose output depends on the client; any other value than the default sends the embed back to the client. */
const SERVER_OPTIONS = [
  "captions", "badge",
  "columns", "columnsTablet", "columnsMobile",
  "gap", "gapRow", "gapColumn",
  "radius", "radiusFull",
  "shadow",
  "hover", "hoverStrength",
  "gutter", "frame", "ratio", "duotone",
  "sort", "exclude", "imageText",
  "lightbox", "linkTo", "linkNewTab",
  "perPage", "loadMore",
] as const;
/** Relative links resolve against this; only the scheme of the result is read. */
const LINK_BASE = "https://example.invalid/";

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

/** The options a server draws. All others stay at their defaults. */
function servable(o: EmbedOptions, defaults: EmbedOptions): boolean {
  const strip = (x: EmbedOptions) => {
    const copy: Record<string, unknown> = { ...x };
    for (const k of SERVER_OPTIONS) delete copy[k];
    return JSON.stringify(copy);
  };
  return strip(o) === strip(defaults);
}

function photoAlt(p: EmbedPhoto, g: EmbedGallery, i: number): string {
  return p.alt || p.title || p.caption || `${g.title} ${i + 1}`;
}

function srcsetOf(p: EmbedPhoto, squareOnly: boolean): string {
  const ratio = p.width && p.height ? p.width / p.height : 0;
  return p.images
    .filter((im) => squareOnly || im.variant !== "thumb" || (ratio && Math.abs(im.width / im.height - ratio) < 0.03))
    .map((im) => `${im.url} ${im.width}w`)
    .join(", ");
}

function bestUrl(p: EmbedPhoto): string {
  const web = p.images.find((im) => im.variant === "web") ?? p.images[p.images.length - 1];
  return web ? web.url : "";
}

function img(p: EmbedPhoto, g: EmbedGallery, i: number, layout: string): string {
  const grid = layout === "grid";
  const set = srcsetOf(p, grid);
  const a = [`alt="${esc(photoAlt(p, g, i))}"`, `src="${esc(bestUrl(p))}"`];
  if (set) a.push(`srcset="${esc(set)}"`, `sizes="${grid ? "(max-width: 600px) 50vw, 33vw" : "(max-width: 600px) 100vw, 50vw"}"`);
  if (p.width && p.height) a.push(`width="${p.width}"`, `height="${p.height}"`);
  a.push('loading="lazy"', 'decoding="async"', 'draggable="false"');
  return `<img ${a.join(" ")}>`;
}

/** The element a tile is drawn in, as render() builds it: a button that opens the lightbox, a link, or an inert box. */
function shell(p: EmbedPhoto, g: EmbedGallery, i: number, layout: string, o: EmbedOptions, u: string): string {
  const inner = img(p, g, i, layout);
  const label = `aria-label="${esc(photoAlt(p, g, i))}"`;
  if (o.lightbox) return `<button class="tile${u}" type="button" ${label}>${inner}</button>`;
  const href = linkHref(p, g, o.linkTo, LINK_BASE);
  if (href) {
    const target = o.linkNewTab ? ' target="_blank" rel="noopener noreferrer"' : "";
    return `<a class="tile${u}" href="${esc(href)}"${target} ${label}>${inner}</a>`;
  }
  if (o.linkTo) return `<div class="tile static${u}">${inner}</div>`;
  return `<button class="tile static${u}" type="button" ${label}>${inner}</button>`;
}

function tile(p: EmbedPhoto, g: EmbedGallery, i: number, layout: string, o: EmbedOptions): string {
  // The grow hover scales the tile, or the figure around tile and caption, so it gets a hook (as in embed.ts).
  const u = o.hover === "grow" ? " u" : "";
  const text = o.captions === "off" ? "" : [p.title, p.caption].filter(Boolean).join(" - ");
  if (!text) return shell(p, g, i, layout, o, u);
  if (o.captions === "below") return `<figure class="item${u}">${shell(p, g, i, layout, o, "")}<figcaption class="below">${esc(text)}</figcaption></figure>`;
  return `<figure class="item ov${u}">${shell(p, g, i, layout, o, "")}<figcaption class="cap">${esc(text)}</figcaption></figure>`;
}

/** The inline filter embed.ts appends after the gallery when a duotone is set. */
function duotone(colours: [string, string]): string {
  const { matrix, tables } = duotoneValues(colours);
  const funcs = (["R", "G", "B"] as const).map((c, i) => `<feFunc${c} type="table" tableValues="${tables[i]}"></feFunc${c}>`).join("");
  return (
    '<svg width="0" height="0" aria-hidden="true" style="position:absolute">' +
    `<filter id="pf-duo" color-interpolation-filters="sRGB"><feColorMatrix type="matrix" values="${matrix}"></feColorMatrix>` +
    `<feComponentTransfer>${funcs}</feComponentTransfer></filter></svg>`
  );
}

/** False for what depends on the client: options a server does not draw, a random order, the original ratio. */
function drawable(o: EmbedOptions): boolean {
  return servable(o, parseOptions(() => null)) && o.sort !== "random" && !o.ratioOriginal;
}

/** The "Show more" button of a paged gallery, hidden when the first page holds every photo; "" without a page size or button. */
function more(o: EmbedOptions, total: number): string {
  if (!o.perPage || !o.loadMore) return "";
  return `<button class="more" type="button"${total <= o.perPage ? " hidden" : ""}>${esc(label("more"))}</button>`;
}

/** The "Made with" credit the platform asks for, or "". */
function badgeLink(g: EmbedGallery): string {
  if (!g.badge?.show) return "";
  return `<a class="${g.badge.prominent ? "badge prominent" : "badge"}" href="${esc(g.badge.url)}" target="_blank" rel="noopener">${esc(badgeText())}</a>`;
}

/** The client counts the whole list for the columns, and only the first page when the button is off. */
function columnCount(o: EmbedOptions, total: number): number {
  return o.perPage && !o.loadMore ? Math.min(o.perPage, total) : total;
}

/**
 * The declarative shadow root for a gallery and the attributes of its host div,
 * or null when the client has to draw it.
 */
export function renderDeclarative(gal: EmbedGallery, attrs: Record<string, string>, lang = ""): string | null {
  const o = parseOptions((n) => attrs[n] ?? null);
  const layout = resolveLayout(attrs["data-layout"] ?? null, gal.layout);
  if (!SERVED_LAYOUTS.includes(layout) || !gal.photos.length || !drawable(o)) return null;
  const photos = selectPhotos(gal.photos, o);
  if (!photos.length) return null;
  const g = { ...gal, photos };
  pickLocale(lang);
  const classes = ["gallery", layout, ...(o.duotone ? ["duo"] : []), ...lookClasses(o, layout)].join(" ");
  const vars = cssVars(o, columnCount(o, photos.length), layout);
  const style = vars ? ` style="${esc(vars)}"` : "";
  const tiles = photos.slice(0, o.perPage || undefined).map((p, i) => tile(p, g, i, layout, o)).join("");
  const badge = o.badge ? badgeLink(g) : "";
  return `<template shadowrootmode="open"><style>${EMBED_CSS}</style><div class="pf"><div class="${classes}"${style}><div class="photos">${tiles}</div>${more(o, photos.length)}</div></div>${o.duotone ? duotone(o.duotone) : ""}${badge}</template>`;
}

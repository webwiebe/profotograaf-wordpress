# Changelog

Versions follow semver. The markup contract (`contract/markup.json`) only grows within a major version; a removal or rename is a new major (see `contract/README.md`).

## 0.1.0

First packaged version (#2530).

- `dist/embed.js`: the gallery embed's interactive layer as one readable script with a source map. It adopts a server-drawn shadow root and draws the grid, masonry and slideshow layouts, the lightbox, favourites and proofing hooks itself when the host sends none.
- `src/`: the TypeScript the script is built from.
- `contract/markup.json` and `contract/majors/1.json`: the markup contract, major 1.
- `fixtures/`: gallery API responses with the expected markup (`*.expected.html`) and the server-drawn markup (`*.server.html`), for the WordPress plugin's parity test.

# Changelog

Versions follow semver. The markup contract (`contract/markup.json`) only grows within a major version; a removal or rename is a new major (see `contract/README.md`).

## 0.3.0

- A server draws the rest of the options a host div can carry (#2859): `data-gutter`, `data-frame`, `data-duotone`, `data-ratio`, `data-image-text`, `data-link-to` with `data-link-new-tab`, `data-lightbox="off"`, `data-sort` and `data-exclude`. A host div that sets any of them was sent back to the client before. The markup contract is unchanged: the classes, custom properties and elements already existed.
- The server's photo list is the one `embed.js` draws: excluded ids dropped, `data-image-text` overrides applied (a caption replaces title and caption, an alt replaces the alt), then sorted (`newest`, `oldest` and `name` are aliases of `reverse`, the payload order and `title`).
- With the lightbox off, a tile is a link (`a.tile`, with `target="_blank" rel="noopener noreferrer"` unless `data-link-new-tab` is off), an inert `div.tile.static` (`data-link-to` is `none`, or points at a page or site the payload lacks) or a `button.tile.static`. Only http(s) targets reach an `href`; a relative one is kept as written. `data-link-to` is ignored while the lightbox is on.
- `data-duotone` adds the `duo` class and the inline `svg` filter (`id="pf-duo"`) after the gallery, before the badge. The numbers are shared with the client through `duotoneValues`.
- `data-gutter` writes nothing on the server: the full-width gutter depends on the host width, so `embed.js` sets `--gutter` after it adopts the markup. It did this for masonry only; grid now follows the host width too. A masonry gallery with `data-ratio` places its columns from that ratio after adopting, as the client does.
- Adopting no longer opens the lightbox from the inert tiles of a gallery whose lightbox is off.
- `fixtures/`: 34 new cases with their `*.expected.html` and `*.server.html`: `duotone-captions-no-lightbox`, `duotone-grid`, `duotone-invalid`, `duotone-short-hex-masonry`, `exclude-ids`, `exclude-reverse`, `image-text-caption`, `image-text-captions-off`, `image-text-entries-ignored`, `image-text-escape`, `image-text-invalid`, `image-text-limits`, `lightbox-off-plain`, `link-file`, `link-ignored-with-lightbox`, `link-none`, `link-page-same-tab`, `link-site-captions-grow`, `link-site-missing`, `link-unsafe-urls`, `look-frame`, `look-frame-masonry-shadow`, `look-gutter`, `look-gutter-masonry`, `look-ratio`, `look-ratio-invalid`, `look-ratio-masonry`, `look-ratio-square-radius-full`, `sort-name-alias`, `sort-newest-alias`, `sort-oldest-alias`, `sort-reverse`, `sort-title` and `sort-unknown`.
- Still drawn by the client only: `data-per-page`, `data-load-more="off"`, `data-sort="random"` and `data-ratio="original"`.

## 0.2.0

- A server draws the look of a gallery: column counts (`data-columns`, `-tablet`, `-mobile`), gap (`data-gap`, `data-gap-row`, `data-gap-column`), radius (`data-radius`, a number or `full`), shadow (`data-shadow`) and hover (`data-hover`, `data-hover-strength`). A host div that sets any of them was sent back to the client before, which showed a blank box and shifted the layout (#2789). The markup contract is unchanged: the classes and custom properties already existed.
- With the `grow` hover the server marks each tile, or the figure around tile and caption, with the `u` class, as `embed.js` does.
- `fixtures/`: ten `look-*` cases with their `*.expected.html` and `*.server.html`, for the WordPress plugin's parity test: `look-columns`, `look-columns-cap` (more columns than photos), `look-gap-radius`, `look-gap-flush`, `look-radius-full`, `look-radius-full-masonry` (the full radius is ignored), `look-shadow-hover`, `look-shadow-strong-grow`, `look-hover-none` and `look-hover-grow-captions`.
- Still drawn by the client only: `data-gutter`, `data-frame`, `data-duotone`, `data-ratio`, `data-image-text`, `data-link-to`, `data-link-new-tab`, `data-sort`, `data-exclude`, `data-per-page` and `data-load-more`.

## 0.1.1

- The API origin comes from a `data-platform` attribute on the script tag when it holds an absolute https origin, and from the script URL otherwise. A copy served from the WordPress plugin folder now reaches the platform (#2653). `contract/markup.json` lists the attribute in a new `script` section.

## 0.1.0

First packaged version (#2530).

- `dist/embed.js`: the gallery embed's interactive layer as one readable script with a source map. It adopts a server-drawn shadow root and draws the grid, masonry and slideshow layouts, the lightbox, favourites and proofing hooks itself when the host sends none.
- `src/`: the TypeScript the script is built from.
- `contract/markup.json` and `contract/majors/1.json`: the markup contract, major 1.
- `fixtures/`: gallery API responses with the expected markup (`*.expected.html`) and the server-drawn markup (`*.server.html`), for the WordPress plugin's parity test.

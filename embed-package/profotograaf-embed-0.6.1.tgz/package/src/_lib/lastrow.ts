// Last row of the original-shape grid (#2389). Every row above fills the width
// by growing its tiles; the last row cannot, or one orphan would stretch across
// the whole width. Left at its base size it came out smaller than the rows above
// with an empty strip on the right. This gives the last row the tile height of
// the row above it, and shrinks it only when that would overflow.

export interface RowTile {
  top: number;
  width: number;
  height: number;
  /** Width over height of the photo. */
  ar: number;
}

/** Rows hold tiles whose tops agree within this many px. */
const ROW_SLACK = 2;
/** A width already this close to its target is left alone. */
const WIDTH_SLACK = 1;

/** Tiles grouped into rows by their top edge, top row first. */
export function rowsOf(tiles: RowTile[]): RowTile[][] {
  const rows: RowTile[][] = [];
  for (const t of tiles) {
    const row = rows.find((r) => Math.abs(r[0].top - t.top) <= ROW_SLACK);
    if (row) row.push(t);
    else rows.push([t]);
  }
  return rows.sort((a, b) => a[0].top - b[0].top);
}

/**
 * Widths for the tiles of the last row, or null when the grid has one row or the
 * last row already has them. The tile height of the row above is kept; when the
 * row would then be wider than the container it is scaled down to fit.
 */
export function lastRowWidths(tiles: RowTile[], containerWidth: number, gap: number): number[] | null {
  const rows = rowsOf(tiles);
  if (rows.length < 2) return null;
  const last = rows[rows.length - 1];
  const h = rows[rows.length - 2][0].height;
  const natural = last.map((t) => t.ar * h);
  const total = natural.reduce((a, b) => a + b, 0) + gap * (last.length - 1);
  const scale = total > containerWidth ? (containerWidth - gap * (last.length - 1)) / (total - gap * (last.length - 1)) : 1;
  const widths = natural.map((w) => w * scale);
  return widths.every((w, i) => Math.abs(w - last[i].width) <= WIDTH_SLACK) ? null : widths;
}

/** Measures the grid's tiles and pins the last row's widths; call after layout and on resize. */
export function fitLastRow(list: HTMLElement, gap: number): void {
  const items = [...list.children].filter((c): c is HTMLElement => c instanceof HTMLElement);
  for (const it of items) it.style.removeProperty("flex");
  const tiles = items.map((it) => {
    const r = it.getBoundingClientRect();
    return { top: r.top, width: r.width, height: r.height, ar: Number(it.style.getPropertyValue("--ar")) || r.width / (r.height || 1) };
  });
  const widths = lastRowWidths(tiles, list.getBoundingClientRect().width, gap);
  if (!widths) return;
  const rows = rowsOf(tiles);
  const last = rows[rows.length - 1];
  widths.forEach((w, i) => items[tiles.indexOf(last[i])].style.setProperty("flex", `0 0 ${w}px`));
}

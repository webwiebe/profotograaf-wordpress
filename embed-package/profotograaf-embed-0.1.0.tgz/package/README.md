# @profotograaf/embed

The interactive layer of the Profotograaf gallery embed, the markup contract it relies on, and the fixtures that pin the markup (#2530).

| Path | What it is |
|---|---|
| `dist/embed.js`, `dist/embed.js.map` | The script: one readable IIFE with a source map. Built, not committed. |
| `src/` | The TypeScript the script is built from. Built (copied), not committed. |
| `contract/markup.json` | Every host attribute, class and ARIA attribute the embed uses. See `contract/README.md` for the change rules. |
| `fixtures/` | Gallery API responses with the expected markup. See `fixtures/README.md`. |

The WordPress plugin renders the fixtures in PHP and compares them with `*.expected.html` after normalization, and loads `dist/embed.js` from its own build.

## Build a package

```
cd web && pnpm build:embed-package
cd ../packages/embed && npm pack
```

`npm pack` writes `profotograaf-embed-<version>.tgz`. The source of truth is `web/src/public/embed`, which the hosted gallery pages build as well; the package is that source laid out for consumers.

## Versions

The version in `package.json` needs a matching entry in `CHANGELOG.md` (a test checks it). `npm publish` is blocked on purpose: a release goes out through the `embed-v*` tag workflow, which does not exist yet.

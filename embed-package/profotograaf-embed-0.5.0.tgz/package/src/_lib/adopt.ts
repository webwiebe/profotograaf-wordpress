// A host whose shadow root arrives already drawn (declarative shadow DOM from a
// server-side renderer, #2530) is adopted instead of fetched and redrawn. The
// lightbox needs the photo list, so it is read back from the markup.

import type { EmbedGallery, EmbedImage, EmbedPhoto } from "./types";

/** The layouts a server draws. A slideshow is drawn at its first slide; the script fetches the rest (resume-slides.ts). */
const ADOPTED = ["grid", "masonry", "slideshow"];

/** The layout of a drawn shadow root when the embed can adopt it, else "". */
export function drawnLayout(root: ShadowRoot | null): string {
  const gallery = root?.querySelector(".pf > .gallery");
  if (!gallery || !root?.querySelector(".tile")) return "";
  return ADOPTED.find((l) => gallery.classList.contains(l)) ?? "";
}

/** srcset entries as images, widest last; the widest is the lightbox photo. */
function imagesOf(img: HTMLImageElement): EmbedImage[] {
  const out: EmbedImage[] = [];
  for (const part of (img.getAttribute("srcset") ?? "").split(",")) {
    const [url, w] = part.trim().split(/\s+/);
    if (url && w?.endsWith("w")) out.push({ variant: "thumb", url, width: parseInt(w, 10), height: 0 });
  }
  const src = img.getAttribute("src") ?? "";
  const web = out.find((im) => im.url === src) ?? out.pop();
  const rest = out.filter((im) => im !== web);
  return [...rest, { variant: "web", url: web?.url ?? src, width: web?.width ?? img.width, height: img.height }];
}

function photoOf(tile: Element, i: number): EmbedPhoto {
  const img = tile.querySelector("img") as HTMLImageElement;
  const item = tile.closest(".item") ?? tile;
  const cap = item.querySelector("figcaption, .cap")?.textContent ?? "";
  const [t, ...c] = cap.split(" - ");
  return {
    id: String(i),
    width: img.width,
    height: img.height,
    alt: img.alt,
    title: c.length ? t : "",
    caption: c.length ? c.join(" - ") : t,
    images: imagesOf(img),
  };
}

/** The gallery as far as the lightbox needs it, in tile order. */
export function galleryFromMarkup(root: ShadowRoot, title: string): EmbedGallery {
  const tiles = [...root.querySelectorAll(".tile")].filter((t) => t.querySelector("img"));
  return {
    id: "",
    title,
    layout: drawnLayout(root),
    url: "",
    photos: tiles.map((t, i) => photoOf(t, i)),
  };
}

# Embed fixtures

Each `<name>.json` is a gallery payload (`gallery`) plus the host attributes (`attrs`) of one embed. Each `<name>.expected.html` is the markup the embed renders for it: the shadow tree, one element per line, without the stylesheet.

`web/src/public/embed/golden.test.ts` renders every fixture with the embed's own renderer and compares it with the expected file. The WordPress plugin renders the same fixtures on the server and must produce the same markup after normalization.

The `look-*` fixtures cover the options a server draws besides captions and the badge: column counts, gap, radius, shadow and hover. `web/src/public/embed/_lib/server.test.ts` renders each one on the server and on the client and compares the trees, and the `*.server.html` files hold the server tree a renderer in another language must produce.

The `duotone-*`, `exclude-*`, `image-text-*`, `lightbox-off-plain`, `link-*`, `look-frame*`, `look-gutter*`, `look-ratio*` and `sort-*` fixtures cover the rest of what a server draws (0.3.0): they are rendered and compared the same way. `link-unsafe-urls` holds the targets that must never reach an `href`, and `image-text-escape` the markup an override must show as text.

Refresh the expected files after an intended change:

```
cd web && npx vitest run -u src/public/embed/golden.test.ts
```

Review the diff of the `.expected.html` files in the pull request: it is the change to the markup contract. To add a case, add a `<name>.json` and run the command above.

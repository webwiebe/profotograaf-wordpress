// Small attribute parsers shared by the embed option modules.

/** The plugin accepts a gap up to 96 px. */
export const MAX_GAP = 96;

/** A whole number within [min, max], else undefined. */
export function parseBoundedInt(v: string | null, min: number, max: number): number | undefined {
  const s = (v ?? "").trim();
  if (!/^\d{1,4}$/.test(s)) return undefined;
  const n = Number(s);
  return n >= min && n <= max ? n : undefined;
}

/** "#rgb", "rgb", "#rrggbb" or "rrggbb" as #rrggbb, else undefined. */
export function hex(s: string): string | undefined {
  const m = /^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(s);
  if (!m) return undefined;
  const h = m[1].length === 3 ? [...m[1]].map((c) => c + c).join("") : m[1];
  return `#${h.toLowerCase()}`;
}

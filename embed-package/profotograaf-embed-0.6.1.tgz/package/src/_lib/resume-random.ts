// A gallery with a random order that the server drew (#2943): the markup carries
// one shuffle, seeded on the server, so every visitor of a cached page would see
// the same order and "Show more" would walk a list the visitor never saw. The
// gallery is fetched once and the drawn tree is replaced by a normal draw, which
// shuffles with Math.random. Until then, and when the payload does not come, the
// drawn tiles stay and open the lightbox from the markup.

import type { EmbedGallery } from "./types";

/** The gallery payload the way mount() fetches it, or null when it does not come or holds no photos. */
async function fetchGallery(host: HTMLElement, base: string): Promise<EmbedGallery | null> {
  const id = encodeURIComponent(host.getAttribute("data-profotograaf-gallery") || "");
  try {
    const res = await fetch(`${base}/api/v1/embed/galleries/${id}`, { credentials: "omit", referrerPolicy: "no-referrer" });
    const g = res.ok ? ((await res.json()) as EmbedGallery) : null;
    return g?.photos?.length ? g : null;
  } catch {
    return null;
  }
}

/** `draw` replaces the drawn tree with a fresh shuffle of `g`. It returns false when nothing is left to show, which keeps the drawn tree. */
export async function resumeRandom(host: HTMLElement, base: string, draw: (g: EmbedGallery) => boolean): Promise<void> {
  const g = await fetchGallery(host, base);
  if (g) draw(g);
}
